package hr.fer.zemris.java.tecaj_9;

import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;

import javax.swing.AbstractAction;
import javax.swing.Action;
import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JToolBar;
import javax.swing.KeyStroke;
import javax.swing.SwingUtilities;
import javax.swing.WindowConstants;
import javax.swing.text.BadLocationException;
import javax.swing.text.Document;

public class JNotepad extends JFrame {

	private JTextArea editor;
	private Path openedFilePath;

	public JNotepad() {
		setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
		setSize(500, 300);
		initGUI();
	}

	private void initGUI() {
		getContentPane().setLayout(new BorderLayout());

		editor = new JTextArea();
		getContentPane().add(new JScrollPane(editor));

		createActions();
		createMenus();
		createToolBars();
	}

	private void createActions() {
		openDocumentAction.putValue(Action.NAME, "Open");
		openDocumentAction.putValue(Action.SHORT_DESCRIPTION,
				"Used to open existing document.");
		openDocumentAction.putValue(Action.ACCELERATOR_KEY,
				KeyStroke.getKeyStroke("control O"));
		openDocumentAction.putValue(Action.MNEMONIC_KEY, KeyEvent.VK_O);

		saveDocumentAction.putValue(Action.NAME, "Save");

		exitAction.putValue(Action.NAME, "Exit");

		deleteSelectedPartAction.putValue(Action.NAME, "Delete");
		toggleCaseAction.putValue(Action.NAME, "Toggle case");

	}

	private void createMenus() {

		JMenuBar menuBar = new JMenuBar();

		JMenu fileMenu = new JMenu("File");
		menuBar.add(fileMenu);

		fileMenu.add(new JMenuItem(openDocumentAction));
		fileMenu.add(new JMenuItem(saveDocumentAction));
		fileMenu.addSeparator();
		fileMenu.add(new JMenuItem(exitAction));

		JMenu editMenu = new JMenu("Edit");
		menuBar.add(editMenu);

		editMenu.add(new JMenuItem(deleteSelectedPartAction));
		editMenu.add(new JMenuItem(toggleCaseAction));

		this.setJMenuBar(menuBar);
	}

	private void createToolBars() {
		JToolBar toolbar = new JToolBar("Alati");
		toolbar.setFloatable(true);
		toolbar.add(new JButton(openDocumentAction));
		toolbar.add(new JButton(saveDocumentAction));
		toolbar.addSeparator();
		toolbar.add(new JButton(toggleCaseAction));

		getContentPane().add(toolbar, BorderLayout.PAGE_START);
	}

	private Action openDocumentAction = new AbstractAction() {

		/**
		 * 
		 */
		private static final long serialVersionUID = 1L;

		@Override
		public void actionPerformed(ActionEvent e) {
			JFileChooser fc = new JFileChooser();
			fc.setDialogTitle("Open file");
			if (fc.showOpenDialog(JNotepad.this) != JFileChooser.APPROVE_OPTION) {
				return;
			}
			Path file = fc.getSelectedFile().toPath();
			if (!Files.isReadable(file)) {
				JOptionPane.showMessageDialog(JNotepad.this,
						"Odabrana datoteka (" + file + ") nije čitljiva.",
						"Pogreška", JOptionPane.ERROR_MESSAGE);
				return;
			}

			try {
				byte[] okteti = Files.readAllBytes(file);
				editor.setText(new String(okteti, StandardCharsets.UTF_8));
				openedFilePath = file;
			} catch (IOException e1) {
				JOptionPane.showMessageDialog(
						JNotepad.this,
						"Pogreška pri čitanju datoteke (" + file + "):"
								+ e1.getMessage(), "Pogreška",
						JOptionPane.ERROR_MESSAGE);
				return;
			}
		}
	};

	private Action saveDocumentAction = new AbstractAction() {

		/**
			 * 
			 */
		private static final long serialVersionUID = 1L;

		@Override
		public void actionPerformed(ActionEvent e) {
			if (openedFilePath == null) {
				JFileChooser fc = new JFileChooser();
				fc.setDialogTitle("Save document");
				if (fc.showSaveDialog(JNotepad.this) != JFileChooser.APPROVE_OPTION) {
					JOptionPane.showMessageDialog(JNotepad.this,
							"Ništa nije pohranjeno.", "Poruka",
							JOptionPane.INFORMATION_MESSAGE);
					return;
				}
				Path file = fc.getSelectedFile().toPath();
				if (Files.exists(file)) {
					int rez = JOptionPane
							.showConfirmDialog(
									JNotepad.this,
									"Odabrana datoteka ("
											+ file
											+ ") već postoji. Jeste li SIGURNI da je želite pregaziti?",
									"Upozerenje", JOptionPane.YES_NO_OPTION,
									JOptionPane.WARNING_MESSAGE);
					if (rez != JOptionPane.YES_OPTION) {
						return;
					}
				}
				openedFilePath = file;
			}
			try {
				Files.write(openedFilePath,
						editor.getText().getBytes(StandardCharsets.UTF_8));
			} catch (IOException e1) {
				JOptionPane.showMessageDialog(JNotepad.this,
						"Pogreška pri zapisivanjudatoteke (" + openedFilePath
								+ "):" + e1.getMessage(), "Pogreška",
						JOptionPane.ERROR_MESSAGE);
			}
		}
	};

	private Action exitAction = new AbstractAction() {

		@Override
		public void actionPerformed(ActionEvent e) {
			dispose();
		}
	};

	private Action deleteSelectedPartAction = new AbstractAction() {

		@Override
		public void actionPerformed(ActionEvent e) {
			Document doc = editor.getDocument();
			int pocetak = Math.min(editor.getCaret().getDot(), editor
					.getCaret().getMark());
			int duljina = Math.max(editor.getCaret().getDot(), editor
					.getCaret().getMark())
					- pocetak;

			try {
				doc.remove(pocetak, duljina);
			} catch (BadLocationException ignorable) {
			}
		}
	};

	private Action toggleCaseAction = new AbstractAction() {

		@Override
		public void actionPerformed(ActionEvent e) {
			Document doc = editor.getDocument();
			int pocetak = Math.min(editor.getCaret().getDot(), editor
					.getCaret().getMark());
			int duljina = Math.max(editor.getCaret().getDot(), editor
					.getCaret().getMark())
					- pocetak;

			try {
				String text = doc.getText(pocetak, duljina);
				text = toggleCase(text);
				doc.remove(pocetak, duljina);
				doc.insertString(pocetak, text, null);
			} catch (BadLocationException ignorable) {
			}
		}

		private String toggleCase(String text) {
			char[] znakovi = text.toCharArray();
			for (int i = 0; i < znakovi.length; i++) {
				char c = znakovi[i];
				if (Character.isLowerCase(c)) {
					znakovi[i] = Character.toUpperCase(c);
				} else if (Character.isUpperCase(c)) {
					znakovi[i] = Character.toLowerCase(c);
				}
			}
			return new String(znakovi);
		}
	};

	public static void main(String[] args) {
		SwingUtilities.invokeLater(() -> {
			new JNotepad().setVisible(true);
		});
	}

}
