package hr.fer.zemris.java.tecaj_9;

import java.awt.FlowLayout;

import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JRadioButton;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;
import javax.swing.UIManager.LookAndFeelInfo;
import javax.swing.WindowConstants;
import javax.swing.plaf.ButtonUI;
import javax.swing.plaf.metal.MetalButtonUI;

public class Prozor extends JFrame {

	public Prozor() {
		setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
		setSize(500, 200);
		getContentPane().setLayout(new FlowLayout());
		getContentPane().add(new JLabel("Ja sam labela"));
		getContentPane().add(new JButton("Stisni me"));
		getContentPane().add(new JCheckBox("Označi me"));
		getContentPane().add(new JRadioButton("Selektiraj me"));

		JButton gumb2 = new JButton("Stisni me 2");
		ButtonUI delegat = (ButtonUI) MetalButtonUI.createUI(gumb2);
		gumb2.setUI(delegat);
		getContentPane().add(gumb2);
	}

	public static void main(String[] args) {
		SwingUtilities.invokeLater(() -> {
			setupApp();
		});
	}

	private static void setupApp() {
		// LookAndFeel laf = new WindowsClassicLookAndFeel(); //restricted
		for (LookAndFeelInfo lafi : UIManager.getInstalledLookAndFeels()) {
			System.out.println(lafi.getClassName());
		}
		try {
			UIManager
					.setLookAndFeel("javax.swing.plaf.nimbus.NimbusLookAndFeel");
		} catch (Exception ignorable) {
		}
		new Prozor().setVisible(true);
	}
}
