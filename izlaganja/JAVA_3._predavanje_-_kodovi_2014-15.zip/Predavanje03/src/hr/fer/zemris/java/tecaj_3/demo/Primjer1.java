package hr.fer.zemris.java.tecaj_3.demo;

import hr.fer.zemris.java.tecaj_3.GeometrijskiLik;

/*
 * Ovo tu mi je ostalo od prošli put, ništ ne valja xd
 * Nemoj mi gledat u komp dok ti pišem komentare, cilj je da te iznenade :D
 */
public class Primjer1 {

	public static void main(String[] args) {
//		GeometrijskiLik l1 = new GeometrijskiLik("Pero");
//		System.out.println(l1.getIme());
//		
//		GeometrijskiLik l2 = l1;
//		System.out.println(l2.getIme());
//		
//		System.out.println(l1.getPovrsina());
	}

}
