package hr.fer.zemris.java.tecaj_3;

public interface SadrziocTocaka {
	boolean sadrziTocku(int x, int y);
}
