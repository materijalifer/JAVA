package hr.fer.zemris.java.tecaj_3;

public interface SizeProvider {
	int getSize();
}
