package hr.fer.zemris.java.tecaj_3.demo;

import hr.fer.zemris.java.tecaj_3.GeometrijskiLik;
import hr.fer.zemris.java.tecaj_3.Pravokutnik;

public class Primjer2 {

	public static void main(String[] args) {
		Pravokutnik p1 = new Pravokutnik("Pero", 1, 1, 10, 20);
		Pravokutnik p2 = new Pravokutnik("Štefica", 2, 2, 15, 15);
	//	GeometrijskiLik l3 = new GeometrijskiLik("Ivo");
		GeometrijskiLik l4 = p1;
		ispisi(p1);
		ispisi(p2);
		//ispisi(l3);
		ispisi(l4);
	}

	private static void ispisi(GeometrijskiLik l) {
		System.out.println("Površina od " + l.getIme() + " je " + l.getPovrsina());
	}
}
