package hr.fer.zemris.java.tecaj_12.servleti;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class PrviServlet extends HttpServlet {

	private static final long serialVersionUID = 1L;

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		
		resp.setContentType("text/html;charset=UTF-8");
		PrintWriter writer = resp.getWriter();
		
		writer.write("<html>\n");
		writer.write(" <head>\n");
		writer.write("  <title>Moja prva stranica iz servleta</title>\n");
		writer.write(" </head>\n");
		writer.write(" <body>\n");
		writer.write("  <h1>Prvi dokument</h1>\n");
		writer.write("   <p>Dobrodošli na našu prvu stranicu koju generira servlet.</p>\n");
		writer.write("   <p>Sada je " + new Date() + ".</p>\n");
		for (int i = 0; i < 3; i++){
			writer.write("   <p>Hello world!!!</p>\n");
		}
		writer.write(" </body>\n");
		writer.write("</html>\n");
		writer.flush();
	}
}
