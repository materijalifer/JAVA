package hr.fer.zemris.java.tecaj_8.p03;

import javax.swing.JFrame;
import javax.swing.SwingUtilities;
import javax.swing.WindowConstants;

public class OtvaranjeProzora extends JFrame {

    private static final long serialVersionUID = 1L;

    public OtvaranjeProzora() {
        setLocation(20, 50);
        setSize(500, 300);
        setTitle("Moj prvi prozor!");
        setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);

        initGUI();
    }

    private void initGUI() {

    }

    public static void main(final String[] args) {

        SwingUtilities.invokeLater(() -> {
            JFrame frame = new OtvaranjeProzora();
            frame.setVisible(true);
        });

    }
}
