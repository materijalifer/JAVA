package hr.fer.zemris.java.tecaj_8.p13;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.GridLayout;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.SwingUtilities;
import javax.swing.WindowConstants;

public class OtvaranjeProzora extends JFrame {

    private static final long serialVersionUID = 1L;

    public OtvaranjeProzora() {
        setLocation(20, 50);
        setSize(500, 300);
        setTitle("Moj prvi prozor!");
        setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);

        initGUI();
    }

    private void initGUI() {
        getContentPane().setLayout(new BorderLayout());
        getContentPane().setBackground(Color.ORANGE);

        JLabel labela = new JLabel("Ovo je tekst labele!");
        JPanel donjiPanel = new JPanel(new GridLayout(1, 0));

        labela.setHorizontalAlignment(SwingConstants.CENTER);

        donjiPanel.add(new JLabel("Unesi broj: "));
        JTextField unosBroja = new JTextField();
        donjiPanel.add(unosBroja);
        JButton izvrsi = new JButton("Izvrši");
        donjiPanel.add(izvrsi);

        izvrsi.addActionListener(e -> {
            obrada(unosBroja.getText(), labela);
        });

        getContentPane().add(labela, BorderLayout.CENTER);
        getContentPane().add(donjiPanel, BorderLayout.PAGE_END);

    }

    private void obrada(final String text, final JLabel labela) {
        try {
            double broj = Double.parseDouble(text);
            double rezultat = broj * broj;
            labela.setText(Double.toString(rezultat));
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Tekst " + text
                    + " nije moguće pretvoriti u broj.", "Pogreška!",
                    JOptionPane.ERROR_MESSAGE);
        }
    }

    public static void main(final String[] args) {

        SwingUtilities.invokeLater(() -> {
            JFrame frame = new OtvaranjeProzora();
            // frame.pack();
            frame.setVisible(true);
        });

    }
}
