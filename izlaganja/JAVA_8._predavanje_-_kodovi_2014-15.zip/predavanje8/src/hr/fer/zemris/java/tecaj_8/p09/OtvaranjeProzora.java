package hr.fer.zemris.java.tecaj_8.p09;

import java.awt.Color;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.SwingConstants;
import javax.swing.SwingUtilities;
import javax.swing.WindowConstants;

public class OtvaranjeProzora extends JFrame {

    private static final long serialVersionUID = 1L;

    public OtvaranjeProzora() {
        setLocation(20, 50);
        setSize(500, 300);
        setTitle("Moj prvi prozor!");
        setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);

        initGUI();
    }

    private void initGUI() {
        getContentPane().setLayout(null);
        getContentPane().setBackground(Color.ORANGE);

        JLabel labela = new JLabel("Ovo je tekst labele!");
        JButton gumb = new JButton("Stisni me");

        labela.setBounds(10, 10, 250, 20);
        labela.setOpaque(true);
        labela.setBackground(Color.WHITE);
        labela.setHorizontalAlignment(SwingConstants.CENTER);
        gumb.setBounds(10, 30, 250, 25);
        getContentPane().add(labela);
        getContentPane().add(gumb);

    }

    public static void main(final String[] args) {

        SwingUtilities.invokeLater(() -> {
            JFrame frame = new OtvaranjeProzora();
            frame.setVisible(true);
        });

    }
}
