package hr.fer.zemris.java.tecaj_8.p02;

import javax.swing.JFrame;
import javax.swing.SwingUtilities;
import javax.swing.WindowConstants;

public class OtvaranjeProzora {

    public static void main(final String[] args) {

        SwingUtilities
                .invokeLater(() -> {
                    JFrame frame = new JFrame();
                    frame.setLocation(20, 50);
                    frame.setSize(500, 300);
                    frame.setTitle("Moj prvi prozor!");
                    // frame.setDefaultCloseOperation(WindowConstants.HIDE_ON_CLOSE);
                    // ->
                    // frame.setVisible(false);
                    // frame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
                    // ->
                    // System.exit(1);
                    frame.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE); // preporuca
                    // se
                    frame.setVisible(true);
                });

    }
}
