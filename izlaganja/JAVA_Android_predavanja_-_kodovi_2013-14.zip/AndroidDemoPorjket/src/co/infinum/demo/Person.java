package co.infinum.demo;

public class Person {
	
	private String name;
	
	private String lastName;
	
	public Person(String name, String lastName) {
		this.name = name;
		this.lastName = lastName;
	}

	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}

	/**
	 * @return the lastName
	 */
	public String getLastName() {
		return lastName;
	}

	
}
