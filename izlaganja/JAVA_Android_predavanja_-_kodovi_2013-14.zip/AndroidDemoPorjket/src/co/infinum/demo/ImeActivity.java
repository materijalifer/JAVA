package co.infinum.demo;

import android.app.Activity;
import android.os.Bundle;
import android.widget.TextView;

public class ImeActivity extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.ime_prezime);
		String ime = getIntent().getExtras().getString("ime", "Nema imena");
		String prezime = getIntent().getExtras().getString("prezime", "Nema prezimena");

		TextView imeTv = (TextView) findViewById(R.id.tvIme);
		TextView prezimeTv = (TextView) findViewById(R.id.tvPrezime);
		
		imeTv.setText(ime);
		prezimeTv.setText(prezime);

	}
}
