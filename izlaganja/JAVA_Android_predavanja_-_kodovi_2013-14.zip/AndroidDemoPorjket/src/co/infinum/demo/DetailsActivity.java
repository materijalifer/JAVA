package co.infinum.demo;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class DetailsActivity extends Activity {
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_details);
		
		TextView labelText = (TextView) findViewById(R.id.tvLabel);
		
		final SharedPreferences prefs = getSharedPreferences("prefs", 0);
		
		String labelValue = getIntent().getExtras().getString("label", "");
		labelText.setText(labelValue);
		
		final EditText editInput = (EditText) findViewById(R.id.etInput);
		editInput.setText(prefs.getString("value", ""));
		
		Button button = (Button) findViewById(R.id.btnSubmit);
		
		button.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				String text = editInput.getText().toString();
				
				Editor editor = prefs.edit();
				editor.putString("value", editInput.getText().toString());
				editor.commit();
				
				Intent intent = new Intent();
				intent.putExtra("data", text);
				
				setResult(RESULT_OK, intent);
				finish();
			}
		});
	}
}
