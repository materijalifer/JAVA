package co.infinum.demo;

import java.util.ArrayList;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ListView;

public class ListActivity extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		
		setContentView(R.layout.activity_list);
		
		ListView listView = (ListView) findViewById(R.id.listView);
		
		final ArrayList<Person> people = new ArrayList<>();
		people.add(new Person("Darth", "Vader"));
		people.add(new Person("Shakira", "Shakirić"));
		people.add(new Person("Timon", "Pumba"));
		people.add(new Person("Stipe", "Pletikosa"));
		
		PersonArrayAdapter adapter = new PersonArrayAdapter(this, people);
		
		listView.setAdapter(adapter);
		
		listView.setOnItemClickListener(new OnItemClickListener() {

			@Override
			public void onItemClick(AdapterView<?> parent, View view,
					int position, long id) {
				Person p = people.get(position);
				
				Intent intent = new Intent(ListActivity.this, ImeActivity.class);
				intent.putExtra("ime", p.getName());
				intent.putExtra("prezime", p.getLastName());
				startActivity(intent);
			}
		});
	}
}
