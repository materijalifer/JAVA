package book.java.threads;

public class PokretanjeDretve1 {

	public static void main(String[] args) {
		
		Thread t = new Thread(() -> {
			Thread current = Thread.currentThread();
			System.out.println("Počinjem: " + current);
			try {
				Thread.sleep(1000);
			} catch (Exception ignorable) {}
			System.out.println("Pozdrav lepi iz nove dretve!");
			System.out.println("Završavam: " + current);
		});
		
		t.start();
//		t.setDaemon(true);
		
		System.out.println("zavši main");
	}
}
