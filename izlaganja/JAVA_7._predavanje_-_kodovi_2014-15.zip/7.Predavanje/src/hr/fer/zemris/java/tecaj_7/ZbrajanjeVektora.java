package hr.fer.zemris.java.tecaj_7;

import java.util.Random;
import java.util.concurrent.Semaphore;

public class ZbrajanjeVektora {

	public static void main(String[] args) {
		
		final int vSize = 500_000;
		
		double[] a = new double[vSize];
		double[] b = new double[vSize];
		double[] rez = new double[vSize];
		
		Random rand = new Random();
		for(int i = 0; i < vSize; i++) {
			a[i] = rand.nextDouble();
			b[i] = rand.nextDouble();
		}
		
		ThreadPool pool = new ThreadPool(2);
		
		
		for(int attempt = 0; attempt < 1000; attempt++) {
//			serialMul(a, b, rez);
//			parallelMul(a, b, rez);
			parallelMul2(a, b, rez, pool);
		}
		
		final int MEASURES = 1_000;
		long t0 = System.currentTimeMillis();
		for(int attempt = 0; attempt < MEASURES; attempt++) {
//			serialMul(a, b, rez);
//			parallelMul(a, b, rez);
			parallelMul2(a, b, rez, pool);
		}
		long t1 = System.currentTimeMillis();
		System.out.println("Vrijeme operacije: " + (t1-t0)/(double)MEASURES + " ms");
		
		pool.shutdown();
	}

	private static void parallelMul2(double[] a, double[] b, double[] rez,
			ThreadPool pool) {
		
		Semaphore sem = new Semaphore(0);
		
		class Posao implements Runnable {

			private int startIndex;
			private int endIndex;
			
			public Posao(int startIndex, int endIndex) {
				super();
				this.startIndex = startIndex;
				this.endIndex = endIndex;
			}

			@Override
			public void run() {
				for(int i = startIndex; i < endIndex; i++) {
					rez[i] = a[i] * b[i];
				}
				sem.release();
				//sem.release(); //isto
			}
	
		}
		pool.addJob(new Posao(0, a.length/2));
		pool.addJob(new Posao(a.length/2, a.length));
		
		sem.acquireUninterruptibly(2);
		//tu je gotovo
	}

	private static void parallelMul(double[] a, double[] b, double[] rez) {
		class Posao implements Runnable {

			private int startIndex;
			private int endIndex;
			
			public Posao(int startIndex, int endIndex) {
				super();
				this.startIndex = startIndex;
				this.endIndex = endIndex;
			}

			@Override
			public void run() {
				for(int i = startIndex; i < endIndex; i++) {
					rez[i] = a[i] * b[i];
				}
			}
	
		}
		
		Thread[] dretve = new Thread[2];
		dretve[0] = new Thread(new Posao(0, a.length/2));
		dretve[1] = new Thread(new Posao(a.length/2, a.length));
		
		dretve[0].start();
		dretve[1].start();
		
f:		for(int i = 0; i < dretve.length; i++) {
			while(true) {
				try {
					dretve[i].join();
					continue f;
				} catch (InterruptedException e) {
				}
			}
		}
		//tu je gotovo
	}
	private static void serialMul(double[] a, double[] b, double[] rez) {
		for(int i = 0; i < a.length; i++) {
			rez[i] = a[i] * b[i];
		}
	}
}
