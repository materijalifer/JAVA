package hr.fer.zemris.java.tecaj_7.upisi;

import java.io.IOException;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;

public class Pisalo {

	//CTRL + SHIFT + F sam ti razlomi!!!
	public static void main(String[] args) throws IOException {
		try (OutputStream os = Files.newOutputStream(
				Paths.get("C:/Java/datoteka.txt"), StandardOpenOption.CREATE,
				StandardOpenOption.WRITE)) {
			String poruka = "Šeće Čevapčić nečim.";
			//UVIJEK KORISTI UTF_8
			byte[] okteti = poruka.getBytes(StandardCharsets.UTF_8);
			os.write(okteti);
		}
	}

}
