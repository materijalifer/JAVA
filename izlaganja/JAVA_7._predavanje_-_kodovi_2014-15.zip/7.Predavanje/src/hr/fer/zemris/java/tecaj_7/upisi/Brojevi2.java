package hr.fer.zemris.java.tecaj_7.upisi;

import java.io.File;

/**
 * Za zadani direktorij vraća broj i ukupnu veličinu
 * pronađenih java datoteka (*.java) koje su bilo gdje unutar
 * te strukture direktorija.
 * 
 * Primjer pokretanja:
 * 
 * Brojevi C:\tecaj
 * 
 * @author Boris
 *
 */
public class Brojevi2 {

	private static class Statistika implements IPosao {
		
		private long brojDatoteka;
		private long ukupnaVelicina;
		
		@Override
		public void prijeDirektorija(File dir) {
			// TODO Auto-generated method stub
			
		}
		@Override
		public void nakonDirektorija(File dir) {
			// TODO Auto-generated method stub
			
		}
		@Override
		public void naDatoteci(File dat) {
			if(dat.getName().endsWith(".java")) {
				brojDatoteka++;
				ukupnaVelicina += dat.length();
			}
		}
	}
	public static void main(String[] args) {
		
//		if(args.length != 1) {
//			printWarning();
//		}
		
		String path = "C:/Java";
		
		File root = new File(path);
		if(!root.exists()) {
			System.out.println("Direktorij ne postoji!");
			return;
		}
		if(!root.isDirectory()) {
			System.out.println(root + " nije direktorij");
			return;
		}
		
		Statistika stat = new Statistika();
		
		listajRekurzivno(root, stat);
		
		System.out.println(stat.brojDatoteka);
		System.out.println(stat.ukupnaVelicina);
		
	}
	
	private static void listajRekurzivno(File dir, Statistika stat) {
		
		File[] children = dir.listFiles();
		if(children == null) {
//			System.out.println("Ne mogu listati " + dir);
			return;
		}
		
		for(File child : children) {
			if(child.isFile()) {
				if(child.getName().endsWith(".java")) {
					stat.brojDatoteka++;
					stat.ukupnaVelicina += child.length();
					listajRekurzivno(child, stat);
				}
			} else {
				listajRekurzivno(child, stat);
			}
		}
		
	}

	
}
