package hr.fer.zemris.java.tecaj_7.upisi;

import java.io.File;

public class ListerUtilty {

	public static void prodiRekurzivno(File dir, IPosao posao) {
		
		posao.prijeDirektorija(dir);
		
		File[] children = dir.listFiles();
		if(children != null) {		
			for(File child : children) {
				if(child.isFile()) {
					posao.naDatoteci(child);
				} else if(child.isDirectory()) {
					prodiRekurzivno(child, posao);
				}
			}
		} 
		
		posao.nakonDirektorija(dir);
		
	}
}
