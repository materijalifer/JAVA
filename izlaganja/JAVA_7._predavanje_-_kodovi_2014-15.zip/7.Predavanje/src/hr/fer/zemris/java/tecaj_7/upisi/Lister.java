package hr.fer.zemris.java.tecaj_7.upisi;

import java.io.File;

/**
 * Prikazuje stablo direktorija i datoteka (indentirano).
 * 
 * Primjer pokretanja:
 * 
 * Liste C:\Java
 * @author Boris
 *
 */
public class Lister {

	public static void main(String[] args) {
		
//		if(args.length != 1) {
//			printWarning();
//		}
		
		String path = "C:/Intel";
		
		File root = new File(path);
		if(!root.exists()) {
			System.out.println("Direktorij ne postoji!");
			return;
		}
		if(!root.isDirectory()) {
			System.out.println(root + " nije direktorij");
			return;
		}
		
		listajRekurzivno(root, 0);
		
	}
	
	private static void listajRekurzivno(File dir, int indentLevel) {
		if(indentLevel == 0) {
			System.out.println(dir);
		} else {
			ispisiDirektorij(indentLevel, dir);
//			System.out.printf("%" + indentLevel + "s%s%n", "", dir.getName());
		}
		
		File[] children = dir.listFiles();
		if(children == null) {
			System.out.println("Ne mogu listati " + dir);
			return;
		}
		
		indentLevel += 2;
		
		for(File child : children) {
			if(child.isFile()) {
				ispisiDirektorij(indentLevel, child);
//				System.out.printf("%" + indentLevel + "s%s%n", "", child.getName());
			} else if(child.isDirectory()) {
				listajRekurzivno(child, indentLevel);
			}
		}
	}

	private static void ispisiDirektorij(int indentLevel, File child) {
		for(int i = 0; i < indentLevel; i++) {
			System.out.print(" ");
		}
		System.out.println(child.getName());
	}

	private static void ispisiIndentirano(File file, int indendacija) {
		
		if(file == null) return;
		
		File[] list = file.listFiles();
		if(list == null) {
			return;
		}
		
		for(File f : list) {
			System.out.println(f.getName());
			ispisiIndentirano(file, indendacija);
		}
		
	}
	
	
	
	private static void printWarning() {
		System.out.println("Dragi korisniče...");
		System.exit(0);
	}
}
