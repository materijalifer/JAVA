package hr.fer.zemris.java.tecaj_7.upisi;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Upisi {

	private static class Student {

		private String jmbag;
		private String prezime;
		private String ime;

		public Student(String jmbag, String prezime, String ime) {
			super();
			this.jmbag = jmbag;
			this.prezime = prezime;
			this.ime = ime;
		}

		
		
		@Override
		public String toString() {
			return ime + " " + prezime  + " (" + jmbag + ")";
		}



		@Override
		public int hashCode() {
			final int prime = 31;
			int result = 1;
			result = prime * result + ((ime == null) ? 0 : ime.hashCode());
			result = prime * result + ((jmbag == null) ? 0 : jmbag.hashCode());
			result = prime * result
					+ ((prezime == null) ? 0 : prezime.hashCode());
			return result;
		}

		@Override
		public boolean equals(Object obj) {
			if (this == obj)
				return true;
			if (obj == null)
				return false;
			if (getClass() != obj.getClass())
				return false;
			Student other = (Student) obj;
			if (ime == null) {
				if (other.ime != null)
					return false;
			} else if (!ime.equals(other.ime))
				return false;
			if (jmbag == null) {
				if (other.jmbag != null)
					return false;
			} else if (!jmbag.equals(other.jmbag))
				return false;
			if (prezime == null) {
				if (other.prezime != null)
					return false;
			} else if (!prezime.equals(other.prezime))
				return false;
			return true;
		}
		
		

	}

	private static class Predmet {

		private String sifra;
		private String naziv;

		public Predmet(String sifra, String naziv) {
			super();
			this.sifra = sifra;
			this.naziv = naziv;
		}
		
		

		@Override
		public String toString() {
			return naziv + " " + "(" + sifra + ")";
//			return "Predmet [sifra=" + sifra + ", naziv=" + naziv + "]";
		}



		@Override
		public int hashCode() {
			final int prime = 31;
			int result = 1;
			result = prime * result + ((naziv == null) ? 0 : naziv.hashCode());
			result = prime * result + ((sifra == null) ? 0 : sifra.hashCode());
			return result;
		}

		@Override
		public boolean equals(Object obj) {
			if (this == obj)
				return true;
			if (obj == null)
				return false;
			if (getClass() != obj.getClass())
				return false;
			Predmet other = (Predmet) obj;
			if (naziv == null) {
				if (other.naziv != null)
					return false;
			} else if (!naziv.equals(other.naziv))
				return false;
			if (sifra == null) {
				if (other.sifra != null)
					return false;
			} else if (!sifra.equals(other.sifra))
				return false;
			return true;
		}

		
	}

	private static class Upis {

		private Student student;
		private Predmet predmet;

		public Upis(Student student, Predmet predmet) {
			super();
			this.student = student;
			this.predmet = predmet;
		}
		
		
		
		

		@Override
		public String toString() {
			return "Upis [student=" + student + ", predmet=" + predmet + "]";
		}





		@Override
		public int hashCode() {
			final int prime = 31;
			int result = 1;
			result = prime * result
					+ ((predmet == null) ? 0 : predmet.hashCode());
			result = prime * result
					+ ((student == null) ? 0 : student.hashCode());
			return result;
		}

		@Override
		public boolean equals(Object obj) {
			if (this == obj)
				return true;
			if (obj == null)
				return false;
			if (getClass() != obj.getClass())
				return false;
			Upis other = (Upis) obj;
			if (predmet == null) {
				if (other.predmet != null)
					return false;
			} else if (!predmet.equals(other.predmet))
				return false;
			if (student == null) {
				if (other.student != null)
					return false;
			} else if (!student.equals(other.student))
				return false;
			return true;
		}

	}

	public static void main(String[] args) throws IOException {

		Map<String, Student> studenti = ucitajStudente();
		Map<String, Predmet> predmeti = ucitajPredmete();
		List<Upis> upisi = ucitajUpise(studenti, predmeti);

		for (Upis u : upisi) {
			System.out.println(u.student + " je upisao " + u.predmet);
		}
	}

	private static List<Upis> ucitajUpise(Map<String, Student> studenti,
			Map<String, Predmet> predmeti) throws IOException {
		List<Upis> result = new ArrayList<>();
		try (BufferedReader reader = new BufferedReader(new InputStreamReader(
				new BufferedInputStream(
						Files.newInputStream(Paths.get("data/upisi.txt"),
								StandardOpenOption.READ)),
						StandardCharsets.UTF_8))) {
			while(true) {
				String redak = reader.readLine();
				if(redak == null) break;
				ukloniKomentar(redak);
				if(redak.isEmpty()) continue;
				String[] elementi = redak.split("\t");
				if(elementi.length != 2) {
					throw new IOException("Pronađen redak s pogrešnim brojem stupaca.");
				}
				Student student = studenti.get(elementi[0]);
				Predmet predmet = predmeti.get(elementi[1]);
				if(student == null) {
					throw new IOException("Pronađen nepostojeći student ("+elementi[0]+") u upisima!");
				}
				if(predmet == null) {
					throw new IOException("Pronađen nepostojeći student ("+elementi[0]+") u upisima!");
				}
				result.add(new Upis(student, predmet));
			}
		} finally {
		}
		return result;
	}

	private static Map<String, Predmet> ucitajPredmete() throws IOException {
		Map<String, Predmet> result = new HashMap<>();
		try (BufferedReader reader = new BufferedReader(new InputStreamReader(
				new BufferedInputStream(
						Files.newInputStream(Paths.get("data/predmeti.txt"),
								StandardOpenOption.READ)),
						StandardCharsets.UTF_8))) {
			while(true) {
				String redak = reader.readLine();
				if(redak == null) break;
				ukloniKomentar(redak);
				if(redak.isEmpty()) continue;
				String[] elementi = redak.split("\t");
				if(elementi.length != 2) {
					throw new IOException("Pronađen redak s pogrešnim brojem stupaca.");
				}
				result.put(elementi[0], new Predmet(elementi[0], elementi[1]));
			}
		}
		return result;
	}
	
	private static String ukloniKomentar(String redak) {
		
		if(redak.contains("REM")) {
			return "";
		}
		int pozicija = redak.indexOf('#');
		if(pozicija != -1) {
			redak = redak.substring(0, pozicija);
		}
		pozicija = redak.indexOf('%');
		if(pozicija != -1) {
			redak = redak.substring(0, pozicija);
		}
		redak = redak.trim();
		return redak;
		
	}

	private static Map<String, Student> ucitajStudente() throws IOException {
		Map<String, Student> result = new HashMap<>();
		try (BufferedReader reader = new BufferedReader(new InputStreamReader(
				new BufferedInputStream(
						Files.newInputStream(Paths.get("data/studenti.txt"),
								StandardOpenOption.READ)),
						StandardCharsets.UTF_8))) {

			while (true) {
				String redak = reader.readLine();
				if (redak == null)
					break;
				ukloniKomentar(redak);
				if (redak.isEmpty())
					continue;
				String[] elementi = redak.split("\t");
				if(elementi.length != 3) {
					throw new IOException("Pronađen redak s pogrešnim brojem stupaca.");
				}
				result.put(elementi[0], new Student(elementi[0], elementi[1],
						elementi[2]));
			}
		}
		return result;
	}

	// napravi za upise i to sve
	/*
	 * 
	 */

}
