package hr.fer.zemris.java.tecaj_7.upisi;

import java.io.File;

public interface IPosao {

	void prijeDirektorija(File dir);
	void nakonDirektorija(File dir);
	void naDatoteci(File dat);
}
