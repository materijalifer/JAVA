package hr.fer.zemris.java.tecaj_7.upisi;

public interface IObrada<T> {

	int brojStupaca();
	
	void obradiRedak(String[] elems);
	
	T dohvatiRezultat();
}
