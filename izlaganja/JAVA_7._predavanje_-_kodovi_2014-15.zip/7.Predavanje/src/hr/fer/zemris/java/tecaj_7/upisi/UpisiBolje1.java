package hr.fer.zemris.java.tecaj_7.upisi;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class UpisiBolje1 {

	private static class Student {

		private String jmbag;
		private String prezime;
		private String ime;

		public Student(String jmbag, String prezime, String ime) {
			super();
			this.jmbag = jmbag;
			this.prezime = prezime;
			this.ime = ime;
		}

		
		
		@Override
		public String toString() {
			return ime + " " + prezime  + " (" + jmbag + ")";
		}



		@Override
		public int hashCode() {
			final int prime = 31;
			int result = 1;
			result = prime * result + ((ime == null) ? 0 : ime.hashCode());
			result = prime * result + ((jmbag == null) ? 0 : jmbag.hashCode());
			result = prime * result
					+ ((prezime == null) ? 0 : prezime.hashCode());
			return result;
		}

		@Override
		public boolean equals(Object obj) {
			if (this == obj)
				return true;
			if (obj == null)
				return false;
			if (getClass() != obj.getClass())
				return false;
			Student other = (Student) obj;
			if (ime == null) {
				if (other.ime != null)
					return false;
			} else if (!ime.equals(other.ime))
				return false;
			if (jmbag == null) {
				if (other.jmbag != null)
					return false;
			} else if (!jmbag.equals(other.jmbag))
				return false;
			if (prezime == null) {
				if (other.prezime != null)
					return false;
			} else if (!prezime.equals(other.prezime))
				return false;
			return true;
		}
		
		

	}

	private static class Predmet {

		private String sifra;
		private String naziv;

		public Predmet(String sifra, String naziv) {
			super();
			this.sifra = sifra;
			this.naziv = naziv;
		}
		
		

		@Override
		public String toString() {
			return naziv + " " + "(" + sifra + ")";
//			return "Predmet [sifra=" + sifra + ", naziv=" + naziv + "]";
		}



		@Override
		public int hashCode() {
			final int prime = 31;
			int result = 1;
			result = prime * result + ((naziv == null) ? 0 : naziv.hashCode());
			result = prime * result + ((sifra == null) ? 0 : sifra.hashCode());
			return result;
		}

		@Override
		public boolean equals(Object obj) {
			if (this == obj)
				return true;
			if (obj == null)
				return false;
			if (getClass() != obj.getClass())
				return false;
			Predmet other = (Predmet) obj;
			if (naziv == null) {
				if (other.naziv != null)
					return false;
			} else if (!naziv.equals(other.naziv))
				return false;
			if (sifra == null) {
				if (other.sifra != null)
					return false;
			} else if (!sifra.equals(other.sifra))
				return false;
			return true;
		}

		
	}

	private static class Upis {

		private Student student;
		private Predmet predmet;

		public Upis(Student student, Predmet predmet) {
			super();
			this.student = student;
			this.predmet = predmet;
		}
		
		
		
		

		@Override
		public String toString() {
			return "Upis [student=" + student + ", predmet=" + predmet + "]";
		}





		@Override
		public int hashCode() {
			final int prime = 31;
			int result = 1;
			result = prime * result
					+ ((predmet == null) ? 0 : predmet.hashCode());
			result = prime * result
					+ ((student == null) ? 0 : student.hashCode());
			return result;
		}

		@Override
		public boolean equals(Object obj) {
			if (this == obj)
				return true;
			if (obj == null)
				return false;
			if (getClass() != obj.getClass())
				return false;
			Upis other = (Upis) obj;
			if (predmet == null) {
				if (other.predmet != null)
					return false;
			} else if (!predmet.equals(other.predmet))
				return false;
			if (student == null) {
				if (other.student != null)
					return false;
			} else if (!student.equals(other.student))
				return false;
			return true;
		}

	}

	public static void main(String[] args) throws IOException {

		Map<String, Student> studenti = ucitajStudente();
		Map<String, Predmet> predmeti = ucitajPredmete();
		List<Upis> upisi = ucitajUpise(studenti, predmeti);

		for (Upis u : upisi) {
			System.out.println(u.student + " je upisao " + u.predmet);
		}
	}

	private static List<Upis> ucitajUpise(Map<String, Student> studenti,
			Map<String, Predmet> predmeti) throws IOException {
		return ObradaTSVDatoteke.ucitaj("data/predmeti.txt", new IObrada<List<Upis>>() {

			private List<Upis> lista = new ArrayList<>();
			
			@Override
			public int brojStupaca() {
				return 2;
			}

			@Override
			public void obradiRedak(String[] elems) {
				Student student = studenti.get(elems[0]);
				Predmet predmet = predmeti.get(elems[1]);
				if(student == null) {
					throw new RuntimeException("Pronađen nepostojeći student ("+elems[0]+") u upisima!");
				}
				if(predmet == null) {
					throw new RuntimeException("Pronađen nepostojeći student ("+elems[0]+") u upisima!");
				}
				lista.add(new Upis(student, predmet));
			}

			@Override
			public List<Upis> dohvatiRezultat() {
				return lista;
			}
			
		});
	}

	private static Map<String, Predmet> ucitajPredmete() throws IOException {
		return ObradaTSVDatoteke.ucitaj("data/predmeti.txt", new IObrada<Map<String, Predmet>>() {

			private Map<String, Predmet> mapa = new HashMap<>();
			
			@Override
			public int brojStupaca() {
				return 2;
			}

			@Override
			public void obradiRedak(String[] elems) {
				mapa.put(elems[0], new Predmet(elems[0], elems[1]));
			}

			@Override
			public Map<String, Predmet> dohvatiRezultat() {
				return mapa;
			}
			
		});
	}

	private static Map<String, Student> ucitajStudente() throws IOException {
		
		return ObradaTSVDatoteke.ucitaj("data/studenti.txt", new IObrada<Map<String, Student>>() {

			private Map<String, Student> mapa = new HashMap<>();
			
			@Override
			public int brojStupaca() {
				return 3;
			}

			@Override
			public void obradiRedak(String[] elems) {
				mapa.put(elems[0], new Student(elems[0], elems[1], elems[2]));
			}

			@Override
			public Map<String, Student> dohvatiRezultat() {
				return mapa;
			}
			
		});
		
		
	}

	// napravi za upise i to sve
	/*
	 * 
	 */

}
