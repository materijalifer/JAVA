package hr.fer.zemris.java.tecaj_7.upisi;

import java.io.File;

public class Lister2 {
	
	private static class IndentiraniIspis implements IPosao {

		private int indentLevel;
		
		@Override
		public void prijeDirektorija(File dir) {
			if(indentLevel == 0) {
				System.out.println(dir);
			} else {
				ispisiDirektorij(indentLevel, dir);
			}
			indentLevel += 2;
		}

		@Override
		public void nakonDirektorija(File dir) {
			indentLevel -= 2;
		}

		@Override
		public void naDatoteci(File dat) {
			ispisiDirektorij(indentLevel, dat);
		}
		
	}
	public static void main(String[] args) {
		
//		if(args.length != 1) {
//			printWarning();
//		}
		
		String path = "C:/Intel";
		
		File root = new File(path);
		if(!root.exists()) {
			System.out.println("Direktorij ne postoji!");
			return;
		}
		if(!root.isDirectory()) {
			System.out.println(root + " nije direktorij");
			return;
		}

		ListerUtilty.prodiRekurzivno(root, new IndentiraniIspis());
		
	}
	
	private static void ispisiDirektorij(int indentLevel, File child) {
		for(int i = 0; i < indentLevel; i++) {
			System.out.print(" ");
		}
		System.out.println(child.getName());
	}

	private static void ispisiIndentirano(File file, int indendacija) {
		
		if(file == null) return;
		
		File[] list = file.listFiles();
		if(list == null) {
			return;
		}
		
		for(File f : list) {
			System.out.println(f.getName());
			ispisiIndentirano(file, indendacija);
		}
		
	}
	
	
	
	private static void printWarning() {
		System.out.println("Dragi korisniče...");
		System.exit(0);
	}


}
