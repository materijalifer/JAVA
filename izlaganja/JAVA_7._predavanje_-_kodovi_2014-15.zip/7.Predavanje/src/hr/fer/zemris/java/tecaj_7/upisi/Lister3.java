package hr.fer.zemris.java.tecaj_7.upisi;

import java.io.File;
import java.io.IOException;
import java.nio.file.FileVisitResult;
import java.nio.file.FileVisitor;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.attribute.BasicFileAttributes;

public class Lister3 {
	
	private static class IndentiraniIspis implements FileVisitor<Path> {

		private int indentLevel;
				@Override
		public FileVisitResult preVisitDirectory(Path dir,
				BasicFileAttributes attrs) throws IOException {
			if(indentLevel == 0) {
				System.out.println(dir);
			} else {
				ispisiDirektorij(indentLevel, dir.toFile());
			}
			indentLevel += 2;
			
			
			return FileVisitResult.CONTINUE;
		}

		@Override
		public FileVisitResult visitFile(Path file, BasicFileAttributes attrs)
				throws IOException {
			ispisiDirektorij(indentLevel, file.toFile());
			return FileVisitResult.CONTINUE;
		}

		@Override
		public FileVisitResult visitFileFailed(Path file, IOException exc)
				throws IOException {
			return FileVisitResult.CONTINUE;
		}

		@Override
		public FileVisitResult postVisitDirectory(Path dir, IOException exc)
				throws IOException {
			indentLevel -= 2;
			return FileVisitResult.CONTINUE;
		}
		
	}
	public static void main(String[] args) {
		
//		if(args.length != 1) {
//			printWarning();
//		}
		
		String path = "C:/Intel";
		
		Path root = Paths.get(path);
		if(!Files.exists(root)) {
			System.out.println("Direktorij ne postoji!");
			return;
		}
		if(!Files.isDirectory(root)) {
			System.out.println(root + " nije direktorij");
			return;
		}

		try {
			Files.walkFileTree(root, new IndentiraniIspis());
		} catch (IOException e) {
			System.out.println("Obilazak prekinut zbog pogreške.");
		}
	}
	
	private static void ispisiDirektorij(int indentLevel, File child) {
		for(int i = 0; i < indentLevel; i++) {
			System.out.print(" ");
		}
		System.out.println(child.getName());
	}

	private static void ispisiIndentirano(File file, int indendacija) {
		
		if(file == null) return;
		
		File[] list = file.listFiles();
		if(list == null) {
			return;
		}
		
		for(File f : list) {
			System.out.println(f.getName());
			ispisiIndentirano(file, indendacija);
		}
		
	}
	
	
	
	private static void printWarning() {
		System.out.println("Dragi korisniče...");
		System.exit(0);
	}


}
