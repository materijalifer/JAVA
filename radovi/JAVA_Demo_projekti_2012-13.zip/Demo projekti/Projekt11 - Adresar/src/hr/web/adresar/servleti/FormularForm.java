package hr.web.adresar.servleti;

import hr.web.adresar.Record;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

public class FormularForm {
	
	private String id;
	private String prezime;
	private String ime;
	private String email;

	Map<String, String> greske = new HashMap<>();
	
	public FormularForm() {
	
	}
	
	public String dohvatiPogresku(String ime) {
		return greske.get(ime);
	}
	
	public boolean imaPogresaka() {
		return !greske.isEmpty();
	}
	
	public boolean imaPogresku(String ime) {
		return greske.containsKey(ime);
	}
	public void popuniIzHttpRequesta(HttpServletRequest req) {
		this.id = pripremi(req.getParameter("id"));
		this.ime = pripremi(req.getParameter("ime"));
		this.prezime = pripremi(req.getParameter("prezime"));
		this.email = pripremi(req.getParameter("email"));
	}
	
	public void popuniIzRecorda(Record r) {
		if(r.getId() == null) {
			this.id = "";
		} else {
			this.id = r.getId().toString();
		}
		
		this.ime = r.getIme();
		this.prezime = r.getPrezime();
		this.email = r.getEmail();
	}
	
	public void popuniURecord(Record r) {
		if(this.id.isEmpty()) {
			r.setId(null);
		} else {
			r.setId(Long.valueOf(this.id));
		}
		
		r.setIme(this.ime);
		r.setPrezime(this.prezime);
		r.setEmail(this.email);
	}
	
	public void validiraj() {
		greske.clear(); //za svaki slučaj; trebala bi biti prazna
		
		if(!this.id.isEmpty()) {
			try{
				Long.parseLong(this.id);
			} catch(NumberFormatException e) {
				greske.put("id", "ID krivo zadan");
			}
		}
		
		if(this.ime.isEmpty()) {
			//prije trimano
			greske.put("ime", "Ime nije zadano");
		}
		if(this.prezime.isEmpty()) {
			//prije trimano
			greske.put("prezime", "Prezime nije zadano");
		}
		if(this.email.isEmpty()) {
			//prije trimano
			greske.put("email", "Email nije zadano");
		} else {
			int l = email.length();
			int p = email.indexOf('@');
			if(l < 3 || p == -1 || p == 0 || p == l - 1) {
				greske.put("email", "Krivi format emaila");
			}
		}
		
	}
	
	private String pripremi(String s) {
		if(s == null) {
			return "";
		} else {
			return s.trim();
		}
	}

	public String getId() {
		return id;
	}

	public String getPrezime() {
		return prezime;
	}

	public String getIme() {
		return ime;
	}

	public String getEmail() {
		return email;
	}

	public void setId(String id) {
		this.id = id;
	}

	public void setPrezime(String prezime) {
		this.prezime = prezime;
	}

	public void setIme(String ime) {
		this.ime = ime;
	}

	public void setEmail(String email) {
		this.email = email;
	}
	
	
}
