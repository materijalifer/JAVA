package hr.fer.zemris.tecaj;
import java.io.File;


public class ListWindowsTree {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		File dir = new File("C:/Windows");
		
		printAll(dir.getParentFile(), 0);

	}
	
	private static void printAll(File dir, int razina) {
		File[] djeca = dir.listFiles();
		
		if (djeca == null) return;
		
		for (File file : djeca) {
			
			if (file.isDirectory()) {
				System.out.println(addTabs(razina) + file.getName());
				printAll(file, razina+1);				
			}
			if (file.isFile()) {
				System.out.println(addTabs(razina) + file.getName());
			}
		}
	}
	
	private static String addTabs(int razina) {
		String tabs = "";
		for (int i=0; i < razina; i++) {
			tabs += "\t";
		}
		return tabs;
	}

}
