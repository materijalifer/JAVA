package hr.fer.zemris.tecaj;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Glavni {
	
	public static void main(String[] args) throws IOException {
		File dir = new File("C:/Users/XSprej/Desktop/OPJJ/TreciProjekt/podaci");
	
		Map<String, Student> studenti = ucitajStudente(new File(dir, "studenti.txt"));
		Map<String, Predmet> predmeti = ucitajPredmete(new File(dir, "predmeti.txt"));
		List<Upis> upisi = ucitajUpise(new File(dir, "upisi.txt"), studenti, predmeti);
		
		ispisiUpise(upisi);		
	}
	
	private static void ispisiUpise(List<Upis> upisi) {
		for(Upis upis : upisi) {
			System.out.println(String.format(
					"| %-40s | %-20s | %-20s |", 
					upis.predmet.naziv,
					upis.student.prezime,
					upis.student.ime
					)				
			);
		}
	}

	private static List<Upis> ucitajUpise(File file,
			Map<String, Student> studenti, Map<String, Predmet> predmeti) throws IOException {
		
		List<Upis> upisi = new ArrayList<>();
		BufferedReader br = null;
		
		try {
			br = new BufferedReader(
					new InputStreamReader(
						new BufferedInputStream(
							new FileInputStream(file)), StandardCharsets.UTF_8));
			while (true) {
				String line = br.readLine();
				
				if (line == null) {	break;	}
				line = line.trim();
				if (line.isEmpty()) { continue; }
				
				String[] elems = line.split("\t");
				if (elems.length != 2) {	continue;	}
				
				Student student = studenti.get(elems[0]);
				Predmet predmet = predmeti.get(elems[1]);
			
				if (student == null || predmet == null) {	continue;	}
				
				Upis upis = new Upis(student, predmet);
				upisi.add(upis);
			}
		} finally {
			if (br != null) {
				try { br.close(); } catch (Exception ignorable) {}
			}
		}
				
		return upisi;
	}

	private static Map<String, Predmet> ucitajPredmete(File file) throws IOException {
		Map<String, Predmet> predmeti = new HashMap<>();
		BufferedReader br = null;
		
		try {
			br = new BufferedReader(
					new InputStreamReader(
						new BufferedInputStream(
							new FileInputStream(file)), StandardCharsets.UTF_8));
			while (true) {
				String line = br.readLine();
				
				if (line == null) {	break;	}
				line = line.trim();
				if (line.isEmpty()) { continue; }
				
				String[] elems = line.split("\t");
				if (elems.length != 2) {	continue;	}
				
				Predmet pred = new Predmet(elems[0], elems[1]);
				predmeti.put(pred.sifra, pred);
			}
		} finally {
			if (br != null) {
				try { br.close(); } catch (Exception ignorable) {}
			}
		}
		
		return predmeti;
	}

	private static Map<String, Student> ucitajStudente(File file) throws IOException {
		Map<String, Student> studenti = new HashMap<>();
		BufferedReader br = null;
		
		try {
			br = new BufferedReader(
					new InputStreamReader(
						new BufferedInputStream(
							new FileInputStream(file)), StandardCharsets.UTF_8));
			while (true) {
				String line = br.readLine();
				
				if (line == null) {	break;	}
				line = line.trim();
				if (line.isEmpty()) { continue; }
				
				String[] elems = line.split("\t");
				if (elems.length != 3) {	continue;	}
				
				Student stud = new Student(elems[0], elems[1], elems[2]);
				studenti.put(stud.jmbag, stud);
			}
		} finally {
			if (br != null) {
				try { br.close(); } catch (Exception ignorable) {}
			}
		}		
		
		return studenti;
	}

	
	
	static class Student {
		String jmbag;
		String prezime;
		String ime;
		
		public Student(String jmbag, String prezime, String ime) {
			super();
			this.jmbag = jmbag;
			this.prezime = prezime;
			this.ime = ime;
		}		
	}
	
	static class Predmet {
		String sifra;
		String naziv;
		
		public Predmet(String sifra, String naziv) {
			super();
			this.sifra = sifra;
			this.naziv = naziv;
		}
	}
	
	static class Upis {
		Student student;
		Predmet predmet;

		public Upis(Student student, Predmet predmet) {
			super();
			this.student = student;
			this.predmet = predmet;
		}
	}

}
