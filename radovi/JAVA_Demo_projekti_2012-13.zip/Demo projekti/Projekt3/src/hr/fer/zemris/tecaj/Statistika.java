package hr.fer.zemris.tecaj;

import java.io.File;
import java.util.HashMap;
import java.util.Map;

@SuppressWarnings("unused")
public class Statistika {

	private static Map<String, Ekstenzija> mapa = new HashMap<>();
	private static int brDatoteka;
	private static int brDirektorija;	
	private static long ukVelDatoteka;
	private static double prosjecnaVelDatoteka;
	
	public static void main(String[] args) {
		if (args.length != 1) {
			System.err.println("O�ekivao sam direktorij");
			System.exit(-1);
		}
		
		brDatoteka = brDirektorija = 0;
		
		File dir = new File(args[0]);
		rekurzivnoProdiSve(dir);

	}
	
	private static void printStats() {
		//TODO
	}
	
	private static void rekurzivnoProdiSve(File dir) {
				
		File[] djeca = dir.listFiles();
		
		if (djeca == null) {
			return;
		}
		
		for (File file: djeca) {
			if (file.isDirectory()) {
				brDirektorija++;
				rekurzivnoProdiSve(file);
			}
			else if (file.isFile()) {
				brDatoteka++;
				dodajFile(file);
			}
		}		
	}
	
	private static void dodajFile(File file) {
		String ekstenzija = getEkstenzija(file);
		
		if (mapa.containsKey(ekstenzija)) {
			Ekstenzija tmp = mapa.get(ekstenzija);
			tmp.setBrojEkstenzija(tmp.getBrojEkstenzija()+1);
			tmp.setUkupnaVelicina(tmp.getUkupnaVelicina() + file.length());
			mapa.put(ekstenzija, tmp);
		}
		
		else {
			Ekstenzija nova = new Ekstenzija(ekstenzija);
			nova.setBrojEkstenzija(1);
			nova.setUkupnaVelicina(file.length());
			mapa.put(ekstenzija, nova);
		}
	}

	private static String getEkstenzija(File file) {
		String[] ekstenzija = file.getName().trim().split("[.+]");
		
		if (ekstenzija[ekstenzija.length-1].equals(file.getName())) {
			return new String("");
		}
		return ekstenzija[ekstenzija.length-1];
	}

	static class Ekstenzija {
		private String naziv;
		private int brojEkstenzija;
		private long ukupnaVelicina;
		
		public Ekstenzija(String naziv) {
			super();
			this.naziv = naziv;
		}

		public int getBrojEkstenzija() {
			return brojEkstenzija;
		}

		public void setBrojEkstenzija(int brojEkstenzija) {
			this.brojEkstenzija = brojEkstenzija;
		}

		public long getUkupnaVelicina() {
			return ukupnaVelicina;
		}

		public void setUkupnaVelicina(long ukupnaVelicina) {
			this.ukupnaVelicina = ukupnaVelicina;
		}

		public double getProsjek() {
			return brojEkstenzija == 0 ? 0.0 : ukupnaVelicina/brojEkstenzija;
		}

		public String getNaziv() {
			return naziv;
		}
		
	}

}
