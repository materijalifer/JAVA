package hr.fer.zemris.tecaj;

import java.io.File;

public class Ispisi {

	public static void main(String[] args) {
		if (args.length != 1) {
			System.err.println("O�ekivao sam direktorij");
			System.exit(-1);
		}
		
		File dir = new File(args[0]);		
		rekurzivnoIspisi(dir);

	}

	private static void rekurzivnoIspisi(File dir) {
		System.out.println(dir);
		
		File[] djeca = dir.listFiles();
		
		if (djeca == null) {
			return;
		}
		
		for (File file: djeca) {
			if (file.isDirectory()) {
				rekurzivnoIspisi(file);
			}
			else if (file.isFile()) {
				System.out.println(file);
			}
		}		
	}

}
