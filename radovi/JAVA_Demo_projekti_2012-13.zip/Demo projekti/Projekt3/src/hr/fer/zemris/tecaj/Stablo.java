package hr.fer.zemris.tecaj;

import java.io.IOException;
import java.nio.file.FileVisitResult;
import java.nio.file.FileVisitor;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.attribute.BasicFileAttributes;

public class Stablo {

	public static void main(String[] args) throws IOException {
		if (args.length != 1) {
			System.err.println("Očekivao sam direktorij");
			System.exit(-1);
		}
		
		Path dir = Paths.get(args[0]);		
		Files.walkFileTree(dir, new Ispis());

	}
	
	static class Ispis implements FileVisitor<Path> {
		String razina = "";
		
		@Override
		public FileVisitResult preVisitDirectory(Path dir, BasicFileAttributes attrs) throws IOException {
			System.out.println(razina + dir.getFileName());
			razina += "  ";			
			return FileVisitResult.CONTINUE;
		}

		@Override
		public FileVisitResult visitFile(Path file, BasicFileAttributes attrs) throws IOException {
			System.out.println(razina + file.getFileName());
			return FileVisitResult.CONTINUE;
		}

		@Override
		public FileVisitResult visitFileFailed(Path file, IOException exc) throws IOException {
			return FileVisitResult.CONTINUE;
		}

		@Override
		public FileVisitResult postVisitDirectory(Path dir, IOException exc) throws IOException {
			razina = razina.substring(0, razina.length()-2);
			return FileVisitResult.CONTINUE;
		}
		
	}
}
