package hr.fer.zemris.java.tecaj_1;

import hr.fer.zemris.java.tecaj_3.prikaz.Slika;

public abstract class GeometrijskiLik {
	
	private String ime;
	
	public GeometrijskiLik(String ime) {
		this.ime = ime;	
	}
	
	public String getIme() {
		return ime;
	}
		
	public void popuniLik(Slika slika) {
		int visina = slika.getVisina();
		int sirina = slika.getSirina();
		
		for (int y=0; y<visina; y++) {
			for (int x=0; x<sirina; x++) {
				if (sadrziTocku(x, y)) {
					slika.upaliTocku(x, y);
				}
			}
		}
	}
	
	@Override
	public String toString() {
		return "Lik" + ime;
	}

	public abstract double getOpseg();	
	public abstract double getPovrsina();	
	public abstract boolean sadrziTocku(int x, int y);
}
