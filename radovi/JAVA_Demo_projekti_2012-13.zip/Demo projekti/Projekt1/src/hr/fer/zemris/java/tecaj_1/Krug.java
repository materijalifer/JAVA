package hr.fer.zemris.java.tecaj_1;

public class Krug extends GeometrijskiLik {

	private int cx;
	private int cy;
	private int r;
	
	public Krug(int cx, int cy, int r) {
		super("Krug");
		this.cx = cx;
		this.cy = cy;
		this.r = r;
	}
	
	@Override
	public double getOpseg() {
		return 2*r*Math.PI;
	}
	
	@Override
	public double getPovrsina() {
		return r*r*Math.PI;
	}
	
	@Override
	public boolean sadrziTocku(int x, int y) {				
		return (cx-x)*(cx-x) + (cy-y)*(cy-y) <= r*r;
	}
	
}
