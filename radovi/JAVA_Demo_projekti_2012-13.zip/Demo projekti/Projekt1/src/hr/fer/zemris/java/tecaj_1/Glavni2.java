package hr.fer.zemris.java.tecaj_1;

import hr.fer.zemris.java.tecaj_3.prikaz.Slika;

public class Glavni2 {

	public static void main(String[] args) {
		Slika slika = new Slika(20, 20);
		
//		GeometrijskiLik lik1 = new Pravokutnik(2, 2, 4, 4);
//		lik1.popuniLik(slika);
		
//		GeometrijskiLik lik2 = new Pravokutnik(8, 7, 8, 9);
//		lik2.popuniLik(slika);
		
		GeometrijskiLik lik3 = new Krug(2, 2, 2);
		lik3.popuniLik(slika);
		
//		GeometrijskiLik lik4 = new Krug(14, 4, 3);
//		lik4.popuniLik(slika);
		
		slika.nacrtajSliku(System.out);
	}

}
