package hr.fer.zemris.java.tecaj_1;

public interface SadrziocTocaka {

}
