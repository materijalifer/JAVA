package hr.fer.zemris.java.tecaj.udp1;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.SocketException;

public class Posluzitelj {
	public static void main(String[] args) throws SocketException, IOException {
		if (args.length != 1) {
			System.err.println("Očekivao 1 argument: port");
			System.exit(-1);
		}
		
		Integer port = Integer.parseInt(args[0]);
		
		@SuppressWarnings("resource")
		DatagramSocket pristupnaTocka = new DatagramSocket(port);
		
		while (true) {
			DatagramPacket paket = new DatagramPacket(new byte[1024], 1024);
			
			
			pristupnaTocka.receive(paket);
			System.out.println("Dobio sam poruku od klijenta: " + paket.getAddress() + ":" + paket.getPort());
			
			String poruka = StringUtil.izvadiOdgovor(paket.getData(), paket.getOffset(), paket.getLength());
			
			System.out.println("Poruka: " + poruka);
			System.out.println();
			
			
			byte[] buf = StringUtil.stvoriPoruku("OK");
			
			DatagramPacket odgovor = new DatagramPacket(buf, buf.length);
			odgovor.setAddress(paket.getAddress());
			odgovor.setPort(paket.getPort());
			
			pristupnaTocka.send(odgovor);
			
		}
		
	}
}
