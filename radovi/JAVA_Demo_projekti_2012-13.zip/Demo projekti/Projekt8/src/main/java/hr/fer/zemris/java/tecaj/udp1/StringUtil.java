package hr.fer.zemris.java.tecaj.udp1;

import java.nio.charset.StandardCharsets;

public class StringUtil {
	
	public static byte[] kodirajUTF8(String tekst) {
		return tekst.getBytes(StandardCharsets.UTF_8);
	}
	
	public static String dekodirajUTF8(byte[] podaci) {
		return new String(podaci, StandardCharsets.UTF_8);
	}
	
	public static String izvadiOdgovor(byte[] data, int offset, int length) {
		byte visi = data[offset];
		byte nizi = data[offset + 1];
		
		int velicina = ((visi << 8) & 0xFF00) | (nizi & 0xFF);
		
		byte[] tekst = new byte[velicina];
		for (int i = 0; i < velicina; i++) {
			tekst[i] = data[offset + i + 2];
		}
		
		return StringUtil.dekodirajUTF8(tekst);
	}

	public static byte[] stvoriPoruku(String poruka) {
		byte[] pomocno = StringUtil.kodirajUTF8(poruka);
		byte[] buf = new byte[2 + pomocno.length];
		
		int velicina = pomocno.length;
		byte nizi = (byte) (velicina & 0xFF);
		byte visi = (byte) ((velicina >> 8) & 0xFF);
		
		buf[0] = visi;
		buf[1] = nizi;
		
		for (int i = 0 ; i < pomocno.length; i++) {
			buf[i+2] = pomocno[i];
		}
		
		return buf;
	}
	
}
