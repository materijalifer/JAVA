package hr.fer.zemris.java.tecaj.udp2;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.SocketException;

public class Posluzitelj {
	public static void main(String[] args) throws SocketException, IOException {
		if (args.length != 1) {
			System.err.println("Očekivao 1 argument: port");
			System.exit(-1);
		}
		
		Integer port = Integer.parseInt(args[0]);
		
		@SuppressWarnings("resource")
		DatagramSocket pristupnaTocka = new DatagramSocket(port);
		
		while (true) {
			DatagramPacket paket = new DatagramPacket(new byte[1024], 1024);
			
			
			pristupnaTocka.receive(paket);
			System.out.println("Dobio sam poruku od klijenta: " + paket.getAddress() + ":" + paket.getPort());
			
			DataInputStream dis = new DataInputStream(new ByteArrayInputStream(paket.getData(), paket.getOffset(), paket.getLength()));
			
			char oper = (char) dis.readByte();
			int brojElem = dis.readShort();
			double rezultat = dis.readDouble();
			for (int i = 1; i < brojElem; i++) {
				switch(oper) {
				case '+':
					rezultat += dis.readDouble();
					break;
				case '-':
					rezultat -= dis.readDouble();
					break;
				case '*':
					rezultat *= dis.readDouble();
					break;
				case '/':
					rezultat /= dis.readDouble();
					break;
				}
			}
			
			
			
			System.out.println("Rezultat je: " + rezultat);
			System.out.println();
			
			ByteArrayOutputStream bos = new ByteArrayOutputStream();
			DataOutputStream dos = new DataOutputStream(bos);
			dos.writeDouble(rezultat);
			
			DatagramPacket odgovor = new DatagramPacket(bos.toByteArray(), bos.size());
			odgovor.setAddress(paket.getAddress());
			odgovor.setPort(paket.getPort());
			
			pristupnaTocka.send(odgovor);
			
		}
		
	}
}
