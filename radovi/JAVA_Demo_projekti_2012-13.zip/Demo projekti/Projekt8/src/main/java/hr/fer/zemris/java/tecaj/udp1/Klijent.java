package hr.fer.zemris.java.tecaj.udp1;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;

/**
 * Primjer poziva:
 * 
 * Klijent IPPosluzitelja PortPosluzitelja Poruka
 * 
 * @author Martin Skec
 *
 */
public class Klijent {

	public static void main(String[] args) throws SocketException, IOException {
		if (args.length != 3) {
			System.err.println("Očekivao sam 3 argumenta: IPPosluzitelja PortPosluzitelja Poruka");
			System.exit(-1);
		}
				
		String imePosluzitelja = args[0];
		InetAddress adresaPosluzitelja = InetAddress.getByName(imePosluzitelja);
		
		int portPosluzitelja = Integer.parseInt(args[1]);		
		String poruka = args[2];
		
		
		byte[] buf = StringUtil.stvoriPoruku(poruka);
		
		// slanje
		DatagramPacket paket = new DatagramPacket(buf, buf.length);
		paket.setAddress(adresaPosluzitelja);
		paket.setPort(portPosluzitelja);
		
		DatagramSocket pristupnaTocka = new DatagramSocket();
		pristupnaTocka.send(paket);
		
		
		// Primanje
		DatagramPacket primljeniPaket = new DatagramPacket(new byte[1024], 1024);
		pristupnaTocka.receive(primljeniPaket);
		
		String odgovor = StringUtil.izvadiOdgovor(primljeniPaket.getData(), primljeniPaket.getOffset(), primljeniPaket.getLength());
		
		System.out.println("Odgovor je: " + odgovor);
		
		pristupnaTocka.close();
	}

	
}
