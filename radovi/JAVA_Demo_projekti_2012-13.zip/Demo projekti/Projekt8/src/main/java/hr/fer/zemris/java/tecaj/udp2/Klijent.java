package hr.fer.zemris.java.tecaj.udp2;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;

/**
 * Primjer poziva:
 * 
 * Klijent IPPosluzitelja PortPosluzitelja Operacija Broj1 ... BrojN
 * 
 * @author Martin Skec
 *
 */
public class Klijent {

	public static void main(String[] args) throws SocketException, IOException {
		if (args.length < 5) {
			System.err.println("Očekivao sam barem 5 argumenta: IPPosluzitelja PortPosluzitelja Operacija Broj1 ... BrojN");
			System.exit(-1);
		}
				
		String imePosluzitelja = args[0];
		InetAddress adresaPosluzitelja = InetAddress.getByName(imePosluzitelja);
		
		int portPosluzitelja = Integer.parseInt(args[1]);
		
		String operacija = args[2];
		if (operacija.length() != 1 || !"+-*/".contains(operacija)) {
			System.err.println("Nije zadana ispravna operacija.");
			System.exit(-1);
		}
		
		ByteArrayOutputStream bos = new ByteArrayOutputStream();
		DataOutputStream dos = new DataOutputStream(bos);
		
		dos.writeByte(operacija.charAt(0));
		dos.writeShort(args.length - 3);
		for (int i = 3; i < args.length; i++) {
			dos.writeDouble(Double.parseDouble(args[i]));
		}
		
		// slanje
		byte[] zaPoslati = bos.toByteArray();
		DatagramPacket paket = new DatagramPacket(zaPoslati, zaPoslati.length);
		paket.setAddress(adresaPosluzitelja);
		paket.setPort(portPosluzitelja);
		
		DatagramSocket pristupnaTocka = new DatagramSocket();
		pristupnaTocka.send(paket);
		
		
		// Primanje
		DatagramPacket primljeniPaket = new DatagramPacket(new byte[8], 8);
		pristupnaTocka.receive(primljeniPaket);
		
		DataInputStream dis = new DataInputStream(new ByteArrayInputStream(primljeniPaket.getData(), primljeniPaket.getOffset(), primljeniPaket.getLength()));
		
		System.out.println("Odgovor je: " + dis.readDouble());
		
		pristupnaTocka.close();
	}

	
}
