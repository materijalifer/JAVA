package hr.fer.zemris.java.tecaj.dns;

import java.net.InetAddress;
import java.net.UnknownHostException;

/**
 * Program razrješava simboličko ime u IP adresu. Pokretanje:
 * NSLookup simbolickoIme
 * @author Martin Skec
 *
 */
public class NSLookup {

	
	public static void main(String[] args) {
		if (args.length != 1) {
			System.err.println("Očekivao sam 1 argument: simolickoIme");
			System.exit(-1);
		}
		
		String ime = args[0];
		
		InetAddress adresa = null;
		try {
			adresa = InetAddress.getByName(ime);
		} catch (UnknownHostException e) {
			System.out.println("Simoličko ime ne postoji.");
			System.exit(1);
		}
		
		System.out.println("IP adresa je " + adresa.getHostAddress());
		
	}

}
