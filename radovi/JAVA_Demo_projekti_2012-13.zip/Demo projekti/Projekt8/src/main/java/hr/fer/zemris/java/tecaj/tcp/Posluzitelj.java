package hr.fer.zemris.java.tecaj.tcp;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketException;
import java.nio.charset.StandardCharsets;
import java.util.Date;

import javax.imageio.ImageIO;

public class Posluzitelj {

	public static void main(String[] args) throws SocketException, IOException {
		if (args.length != 1) {
			System.err.println("Očekivao 1 argument: port");
			System.exit(-1);
		}

		Integer port = Integer.parseInt(args[0]);

		@SuppressWarnings("resource")
		ServerSocket posluziteljskaPristupnaTocka = new ServerSocket(port);

		while (true) {

			Socket klijent = null;

			try {
				klijent = posluziteljskaPristupnaTocka.accept();
			} catch (IOException e) {
				continue;
			}

			new Thread(new Radnik(klijent)).start();
		}

	}

	private static class Radnik implements Runnable {

		private Socket klijent;
		private InputStream ulaz;
		private OutputStream izlaz;

		public Radnik(Socket klijent) {
			super();
			this.klijent = klijent;
		}

		@Override
		public void run() {
			try {
				ulaz = new BufferedInputStream(klijent.getInputStream());
				izlaz = new BufferedOutputStream(klijent.getOutputStream());

				obrada();

			} catch (Exception e) {
				System.err.println(e.getMessage());
			} finally {
				try {
					izlaz.flush();
				} catch (IOException ignorable) {
				}
				try {
					klijent.close();
				} catch (IOException ignorable) {
				}
			}

		}

		private void obrada() throws IOException {
			BufferedReader reader = new BufferedReader(new InputStreamReader(
					ulaz, StandardCharsets.ISO_8859_1));

			StringBuilder zaglavlje = new StringBuilder();
			String prviRedak = reader.readLine();
			zaglavlje.append(prviRedak).append('\n');
			while (true) {
				String ostalo = reader.readLine();

				if (ostalo == null || ostalo.trim().isEmpty())
					break;

				zaglavlje.append(ostalo).append('\n');
			}

			System.out.println(
					"Obrađujem klijenta: " + klijent.getRemoteSocketAddress() + "\n" +
					"Zaglavlje je: \n" +
					zaglavlje.toString() + "\n\n"
			);
				
			String[] elementi = prviRedak.split(" ");
			if (elementi[0].equals("GET")) {
				if (elementi[1].equals("/now")) {
					generirajNow();
					return;
				}
				else if (elementi[1].equals("/slika")){
					generirajSlika();
					return;
				}
			}
			posaljiTekst(200, "text/plain; charset=UTF-8", "Ništa još nije implementirano");

		}

		private void generirajSlika() throws IOException {
			BufferedImage bim = new BufferedImage(400, 200, BufferedImage.TYPE_3BYTE_BGR);
			
			Graphics2D g = bim.createGraphics();
			
			g.setColor(Color.YELLOW);
			g.fillRect(0, 0, 400, 200);
			
			g.setColor(Color.GREEN);
			g.fillOval(20, 10, 200, 150);
			
			g.setColor(Color.RED);
			g.fillRect(200, 100, 150, 80);
			
			g.setColor(Color.BLACK);
			g.drawString(new Date().toString(), 10, 190);
			
			g.dispose();
			
			ByteArrayOutputStream bos = new ByteArrayOutputStream();
			ImageIO.write(bim, "png", bos);
			
			byte[] podaci = bos.toByteArray();
			posaljiBinarno(200, "image/png", podaci);
		}

		private void generirajNow() throws IOException {
			
			StringBuilder sb = new StringBuilder();
			
			sb.append("<html>\n")
				.append("  <head>\n")
				.append("    <title>Točno vrijeme</title>\n")
				.append("  </html>\n")
				.append("  <body>\n")
				.append("    <p>Sada je: ").append(new Date()).append("</p>\n")
				.append("    <img src='/slika'>\n")
				.append("  </body>\n")
				.append("</html>\n");
			
			posaljiTekst(200, "text/html; charset=UTF-8", sb.toString());
		}

		public void posaljiTekst(int status, String mime, String tekst) throws IOException {
			posaljiBinarno(status, mime, tekst.getBytes(StandardCharsets.UTF_8));
		}
		
		private void posaljiBinarno(int status, String mime, byte[] bytes) throws IOException {
			StringBuilder zaglavlje = new StringBuilder();
			
			// Prvi redak:
			zaglavlje.append("HTTP/1.0").append(status).append(" ");			
			switch (status) {
			case 200: zaglavlje.append("OK"); break;
			case 404: zaglavlje.append("File not found"); break;				
			default: zaglavlje.append("X"); break;
			}			
			zaglavlje.append("\r\n");
			
			// Content-Type:
			zaglavlje.append("Content-Type: ").append(mime).append("\r\n");
			
			// Content-Length
			zaglavlje.append("Content-Length").append(bytes.length).append("\r\n");
			
			// Zadnji redak (prazan)
			zaglavlje.append("\r\n");
			
			izlaz.write(zaglavlje.toString().getBytes(StandardCharsets.ISO_8859_1));
			izlaz.write(bytes);
			
		}

	}
}
