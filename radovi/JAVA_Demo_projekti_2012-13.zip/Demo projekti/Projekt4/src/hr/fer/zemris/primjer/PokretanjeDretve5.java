package hr.fer.zemris.primjer;


public class PokretanjeDretve5 {

	static long brojac = 0;
	
	public static void main(String[] args) {
		
		final long brojUvecavanja = 1_000_000;
		
		final String kontrolor = new String("Ja upravljam dretvama.");		
		
		Thread[] dretve = new Thread[5];
		
		for (int i=0; i<dretve.length; i++) {
			dretve[i] = new Thread(new MojPosao(kontrolor, brojUvecavanja), "radnik" + (i+1));
		}
		
		for (int i=0; i<dretve.length; i++) {
			dretve[i].start();
		}
		
		for (int i=0; i<dretve.length; i++) {
			try {
				dretve[i].join();
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
		
		System.out.println("Ja sam zadnja živa dretva, a brojač je: " + brojac);
		
	}
	
	static class MojPosao implements Runnable {
			
		 long brojUvecavanja;
		 private Object kontrolor;
				
		public MojPosao(Object kontrolor, long brojUvecavanja) {
			super();
			this.brojUvecavanja = brojUvecavanja;
			this.kontrolor = kontrolor;
		}

		@Override
		public void run() {
			for (long i=0; i<brojUvecavanja; i++) {
				synchronized(kontrolor) {
					brojac = brojac + 1;
				}
			}
			
		}
	}

}
