package hr.fer.zemris.java_tecaj;

import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSplitPane;
import javax.swing.JTextField;
import javax.swing.ListModel;
import javax.swing.SwingUtilities;
import javax.swing.WindowConstants;
import javax.swing.event.ListDataEvent;
import javax.swing.event.ListDataListener;

public class Program1 extends JFrame {

	private static final long serialVersionUID = 1L;

	public Program1() {
		setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
		setTitle("Moj prvi prozor");
		setLocation(10, 10);
		setSize(300, 400);
		initGUI();
		// pack();
	}

	@SuppressWarnings("unused")
	private void initGUI() {
		getContentPane().setLayout(new BorderLayout());

		// model podataka
		ListModel<Integer> model1 = new ParniBrojeva(0, 5);
		final VarijabilniModel model2 = new VarijabilniModel();
		model2.dodaj(5);
		model2.dodaj(7);
		model2.dodaj(-6);
		model2.dodaj(21);
		model2.dodaj(42);

		// pogled
		JList<Integer> lista1 = new JList<Integer>(model2); // pogled->bijela
															// povrsina
		final JList<Integer> lista2 = new JList<Integer>(model2);
		BrojElemenata<Integer> brojElemenata = new BrojElemenata<Integer>(
				model2);

		JSplitPane splitter = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT,
				new JScrollPane(lista1), new JScrollPane(lista2));

		final JTextField tfBroj = new JTextField();
		JButton btnDodaj = new JButton("Dodaj");
		JButton btnObrisi = new JButton("Obrisi");
		JPanel panel = new JPanel(new GridLayout(1, 3));
		panel.add(tfBroj);
		panel.add(btnDodaj);
		panel.add(btnObrisi);

		btnDodaj.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				String uneseniText = tfBroj.getText();
				try {
					Integer vrijednost = Integer.valueOf(uneseniText);
					model2.dodaj(vrijednost);
					tfBroj.setText("");
				} catch (NumberFormatException ex) {
					JOptionPane
							.showMessageDialog(
									Program1.this,
									"Dragi korisniče, to što si unio ne da se protumačiti kao broj.",
									"Greška", JOptionPane.ERROR_MESSAGE);
				}

			}
		});
		btnObrisi.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				int oznaceniIndeks= lista2.getSelectedIndex();
				if(oznaceniIndeks==-1){
					return;
				}
				model2.obrisi(oznaceniIndeks);
				
			}
		});
		getContentPane().add(splitter, BorderLayout.CENTER);
		getContentPane().add(brojElemenata, BorderLayout.PAGE_START);
		getContentPane().add(panel, BorderLayout.PAGE_END);
	}

	private static class BrojElemenata<E> extends JLabel {
		/**
		 * 
		 */
		private static final long serialVersionUID = 1L;
		private ListModel<E> modelListe;

		public BrojElemenata(ListModel<E> modelListe) {
			super();
			this.modelListe = modelListe;
			azurirajTekst();
			modelListe.addListDataListener(new ListDataListener() {

				@Override
				public void intervalRemoved(ListDataEvent e) {
					azurirajTekst();
					BrojElemenata.this.modelListe.removeListDataListener(this);

				}

				@Override
				public void intervalAdded(ListDataEvent e) {
					azurirajTekst();

				}

				@Override
				public void contentsChanged(ListDataEvent e) {
					azurirajTekst();

				}
			});
		}

		private void azurirajTekst() {
			setText("Broj elemenata liste je: " + modelListe.getSize() + ".");
		}

	}

	private static class VarijabilniModel implements ListModel<Integer> {
		private List<Integer> podaci = new ArrayList<Integer>();
		private List<ListDataListener> promatraci = new ArrayList<ListDataListener>();

		@Override
		public int getSize() {
			return podaci.size();
		}

		public void obrisi(int index) {
			podaci.remove(index);
			int pozicija=index;
			ListDataEvent opis = new ListDataEvent(this,
					ListDataEvent.INTERVAL_REMOVED, pozicija, pozicija);
			ListDataListener[] kopija = new ListDataListener[promatraci.size()];
			promatraci.toArray(kopija);
			for (ListDataListener l : kopija) {
				l.contentsChanged(opis);
			}
			
		}

		public void dodaj(Integer value) {
			podaci.add(value); // treba dojaviti pogledu da je doslo do promijene
			int pozicija = podaci.size() - 1;
			ListDataEvent opis = new ListDataEvent(this,
					ListDataEvent.INTERVAL_ADDED, pozicija, pozicija);
			for (ListDataListener l : promatraci) {
				l.contentsChanged(opis);
			}
		}

		@Override
		public Integer getElementAt(int index) {
			return podaci.get(index);
		}

		@Override
		public void addListDataListener(ListDataListener l) { // listDataListener
																// je promatrac
			System.out.println("Imam registraciju: " + l);
			promatraci.add(l);
		}

		@Override
		public void removeListDataListener(ListDataListener l) {
			promatraci.remove(l);
		}

	}

	/**
	 * Razred koji se koristi stvaranje komponenti koji se renderiraju na JListi
	 * 
	 * @author Dominik Šišejković
	 * 
	 */
	private static class ParniBrojeva implements ListModel<Integer> {
		private int prvi;
		private int n;

		public ParniBrojeva(int prvi, int n) {
			super();
			this.prvi = prvi;
			this.n = n;
		}

		@Override
		public int getSize() {
			return n;
		}

		@Override
		public Integer getElementAt(int index) {
			return prvi + index * 2;
		}

		@Override
		public void addListDataListener(ListDataListener l) {
		}

		@Override
		public void removeListDataListener(ListDataListener l) {
		}

	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		SwingUtilities.invokeLater(new Runnable() {
			@Override
			public void run() {
				new Program1().setVisible(true);
			}
		});

	}

}
