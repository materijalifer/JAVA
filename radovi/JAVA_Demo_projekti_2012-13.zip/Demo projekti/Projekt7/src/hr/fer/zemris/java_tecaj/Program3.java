package hr.fer.zemris.java_tecaj;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Point;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.SwingUtilities;
import javax.swing.WindowConstants;

/**
 * Vektorsko crtanje
 * 
 * @author Dominik Šišejković
 * 
 */
public class Program3 extends JFrame {

	private static final long serialVersionUID = 1L;

	private static class Linija {
		Point p1;
		Point p2;

		public Linija(Point p1, Point p2) {
			super();
			this.p1 = p1;
			this.p2 = p2;
		}
	}

	public Program3() {
		setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
		setTitle("Moj prvi prozor");
		setLocation(10, 10);
		setSize(300, 400);
		initGUI();
		// pack();
	}

	private void initGUI() {
		getContentPane().setLayout(new BorderLayout());

		MojaKomponenta mk = new MojaKomponenta();

		getContentPane().add(mk, BorderLayout.CENTER);

	}

	private static class MojaKomponenta extends JComponent {
		private static final long serialVersionUID = 1L;
		private List<Linija> linije = new ArrayList<Linija>();
		private Point pocetak;
		private Point kraj;

		public MojaKomponenta() {
			addMouseListener(new MouseListener() {

				@Override
				public void mouseReleased(MouseEvent e) {

				}

				@Override
				public void mousePressed(MouseEvent e) {
					if (pocetak == null) {
						pocetak = new Point(e.getX(), e.getY());
						kraj = new Point(e.getX(), e.getY());
					} else {
						kraj.x = e.getX();
						kraj.y = e.getY();
						linije.add(new Linija(pocetak, kraj));
						pocetak = null;
						kraj = null;
					}

					// obavijestiti komponentu da je doslo do promijene
					repaint(); // nece odmah nacrtati komponentu-> EDT ce cekat
								// da nebi za svaku malu promjenu iscrtavao, vec
								// nakon vise promjena
					
				}

				@Override
				public void mouseExited(MouseEvent e) {
					// TODO Auto-generated method stub

				}

				@Override
				public void mouseEntered(MouseEvent e) {
					// TODO Auto-generated method stub

				}

				@Override
				public void mouseClicked(MouseEvent e) {
					// TODO Auto-generated method stub

				}
			});

			addMouseMotionListener(new MouseMotionListener() {
				
				@Override
				public void mouseMoved(MouseEvent e) {
					if(pocetak!=null){
						kraj.x = e.getX();
						kraj.y = e.getY();
						repaint();
					}
					
				}
				
				@Override
				public void mouseDragged(MouseEvent e) {
					// TODO Auto-generated method stub
					
				}
			});
		}

		@Override
		protected void paintComponent(Graphics g) {
			g.setColor(Color.RED);
			for (Linija l : linije) {  //uvijek je potrebno iscrati sve iz pocetka..
				g.drawLine(l.p1.x, l.p1.y, l.p2.x, l.p2.y);
			}
			
			if(pocetak!=null){
				g.setColor(Color.BLUE);
				g.drawLine(pocetak.x,pocetak.y,kraj.x,kraj.y);
			}

		}
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		SwingUtilities.invokeLater(new Runnable() {
			@Override
			public void run() {
				new Program3().setVisible(true);
			}
		});

	}

}
