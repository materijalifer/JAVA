package hr.fer.zemris.java.tecaj;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.SwingUtilities;
import javax.swing.WindowConstants;

@SuppressWarnings("serial")
public class Program2 extends JFrame {

	public Program2() {
		this.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
		this.setTitle("Moj prvi prozor.");
		this.setLocation(10, 10);				// gornji lijevi ugao prozora, kordinate su kordinate na desktopu
		this.setSize(500, 200);
		
		initGUI();
	}
	
	
	private void initGUI() {
		this.getContentPane().setLayout(null);
		
		JLabel labela = new JLabel("Hello world!");
		labela.setLocation(20, 10);
//		labela.setSize(150, 15);
		labela.setSize(labela.getPreferredSize());				// bolji nacin
		labela.setOpaque(true);
		labela.setBackground(Color.YELLOW);
		labela.setForeground(Color.BLUE);

		JButton gumb1 = new JButton("Stisni me");
		Dimension dim = gumb1.getPreferredSize();
		gumb1.setLocation(20, 30);
		gumb1.setSize(dim.width, dim.height);
		
		JButton gumb2 = new JButton("Stisni me");
		gumb2.setLocation(gumb1.getLocation().x + gumb1.getWidth() + 10, 30);
		gumb2.setSize(gumb2.getPreferredSize());


		this.getContentPane().add(labela);
		this.getContentPane().add(gumb1);
		this.getContentPane().add(gumb2);
		
		gumb1.addActionListener(new MojPosao1());
		gumb2.addActionListener(new ActionListener() {			
			@Override
			public void actionPerformed(ActionEvent e) {
				System.out.println("Korisnik je stisnuo drugi gumb!");				
			}
		});

	}


	static class MojPosao1 implements ActionListener {

		@Override
		public void actionPerformed(ActionEvent e) {
			System.out.println("Korisnik je stisnuo prvi gumb!");			
		}
		
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	// inicijalizacija programa...
	public static void main(String[] args) {
		
		System.out.println("Metodu main() izvodi dretva: " + Thread.currentThread().getName());
		
		SwingUtilities.invokeLater(new Runnable() {
			// Event dispatching thread: EDT
			@Override
			public void run() {
				System.out.println("Metodu run() izvodi dretva: " + Thread.currentThread().getName());
				startGUIApp();
			}
		});
	}

	protected static void startGUIApp() {
		new Program2().setVisible(true);
	}

}
