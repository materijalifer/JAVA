package hr.fer.zemris.java.tecaj;

import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;
import javax.swing.WindowConstants;

@SuppressWarnings("serial")
public class Program3 extends JFrame {

	private JTextField broj;
	
	public Program3() {
		this.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
		this.setTitle("Kalkulator");
		this.setLocation(10, 10);
		this.setSize(500, 200);
		this.setResizable(false);
		initGUI();
		
		this.pack();
	}

	private void initGUI() {
		this.getContentPane().setLayout(new BorderLayout());
		
		broj = new JTextField("0");
		
		this.getContentPane().add(broj, BorderLayout.PAGE_START);
		
		JPanel panel = new JPanel();
		panel.setBorder(BorderFactory.createTitledBorder("Operacije"));
		panel.setLayout(new GridLayout(2, 3, 4, 2));
		this.getContentPane().add(panel, BorderLayout.CENTER);		
		
		JButton gumb1 = new JButton("sin(x)");
		JButton gumb2 = new JButton("cos(x)");
		JButton gumb3 = new JButton("tan(x)");
		JButton gumb4 = new JButton("e^x");
		JButton gumb5 = new JButton("log(x)");
		JButton gumb6 = new JButton("ln(x)");
		
		panel.add(gumb1);
		panel.add(gumb2);
		panel.add(gumb3);
		panel.add(gumb4);
		panel.add(gumb5);
		panel.add(gumb6);
				
		gumb1.addActionListener(new ActionListener() {			
			@Override
			public void actionPerformed(ActionEvent e) {
				izracunaj(new ITransformacija() {
					@Override
					public double transformiraj(double x) {
						return Math.sin(x);
					}
				});
			}
		});
		gumb2.addActionListener(new ActionListener() {			
			@Override
			public void actionPerformed(ActionEvent e) {
				izracunaj(new ITransformacija() {
					@Override
					public double transformiraj(double x) {
						return Math.cos(x);
					}
				});
			}
		});
		gumb3.addActionListener(new ActionListener() {			
			@Override
			public void actionPerformed(ActionEvent e) {
				izracunaj(new ITransformacija() {
					@Override
					public double transformiraj(double x) {
						return Math.tan(x);
					}
				});
			}
		});
		gumb4.addActionListener(new ActionListener() {			
			@Override
			public void actionPerformed(ActionEvent e) {
				izracunaj(new ITransformacija() {
					@Override
					public double transformiraj(double x) {
						return Math.exp(x);
					}
				});
			}
		});
		gumb5.addActionListener(new ActionListener() {			
			@Override
			public void actionPerformed(ActionEvent e) {
				izracunaj(new ITransformacija() {
					@Override
					public double transformiraj(double x) {
						return Math.log10(x);
					}
				});
			}
		});
		gumb6.addActionListener(new ActionListener() {			
			@Override
			public void actionPerformed(ActionEvent e) {
				izracunaj(new ITransformacija() {
					@Override
					public double transformiraj(double x) {
						return Math.log(x);
					}
				});
			}
		});
	
		JMenuBar traka = new JMenuBar();
		this.setJMenuBar(traka);
		
		JMenu operacije = new JMenu("Operacije");
		traka.add(operacije);
		
		JMenuItem stavka1 = new JMenuItem("sin(x)");
		operacije.add(stavka1);
		stavka1.addActionListener(gumb1.getActionListeners()[0]);

		JMenuItem stavka2 = new JMenuItem("cos(x)");
		operacije.add(stavka2);
		stavka2.addActionListener(gumb2.getActionListeners()[0]);
	
	}

	private static interface ITransformacija {
		double transformiraj(double x);
	}
	
	private void izracunaj(ITransformacija transf) {
		String text = broj.getText();
		double x = 0;
		
		try {
			x = Double.parseDouble(text);
		} catch (NumberFormatException ex) {
			JOptionPane.showMessageDialog(
					Program3.this,
					"Dragi korisniče, ono što si unio ne da se protumačiti kao broj. Pokušaj ponovno.",
					"Pogreška",
					JOptionPane.ERROR_MESSAGE
				);
		}
		
		double rezultat = transf.transformiraj(x);
		
		broj.setText(String.valueOf(rezultat));
	}
	
	// inicijalizacija programa...
	public static void main(String[] args) {

		System.out.println("Metodu main() izvodi dretva: "
				+ Thread.currentThread().getName());

		SwingUtilities.invokeLater(new Runnable() {
			// Event dispatching thread: EDT
			@Override
			public void run() {
				System.out.println("Metodu run() izvodi dretva: "
						+ Thread.currentThread().getName());
				startGUIApp();
			}
		});
	}

	protected static void startGUIApp() {
		new Program3().setVisible(true);
	}

}
