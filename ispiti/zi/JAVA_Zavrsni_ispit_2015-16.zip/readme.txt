-> prolaz je bilo potrebno rjesiti cijeli prvi, cijeli drugi te treci zadatak bez crtanja histograma
-> ispit se pisao 2 i pol sata
-> PROLAZNOST 16/70+
-> savjeti	-> pripremiti projekt za web-aplikaciju
			-> izvjezbati swing i web-aplikacije (tomcat)
				-> pojave se svake godine
-> ako imate srecu nece vam rjesenja pregledavati Cupic

SRETNO buducim generacijama
