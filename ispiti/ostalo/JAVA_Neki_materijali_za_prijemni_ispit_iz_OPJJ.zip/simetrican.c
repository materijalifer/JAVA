#include <stdio.h>
#include <string.h>

int simetrican(char *s) {
	int dulj = strlen(s);
	int i;
	for (i=0; i<=dulj/2; i++) {
		printf(" %c\n", *(s+dulj-i-1));
		if (*(s+i) != *(s+dulj-i-1))
			return 0;
	}
	return 1;
}


int main (int argc, char *argv[]){
	char *niz = argv[1];
	if (simetrican(niz)){
		printf("Niz je simetrican.");
	}
	else 
		printf("Niz nije simetrican.");
	return 0;
}