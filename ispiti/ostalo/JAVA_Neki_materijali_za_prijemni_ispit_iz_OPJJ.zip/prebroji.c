#include <stdio.h>

int prebroji (int broj, int znamenka){
	if (broj<=0){
		return 0;
	}
	if (broj%10 == znamenka){
		return 1 + prebroji (broj/10, znamenka);
	}
	else 
		return 0 + prebroji(broj/10, znamenka);
}

int main (void) {
	int broj, znamenka;
	printf("unesite broj i znamenku: ");
	scanf("%d %d", &broj, &znamenka);
	printf("Znamenka %d se pojavlja %d puta\n",znamenka, prebroji(broj,znamenka));
	return 0;
}