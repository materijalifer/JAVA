#include <stdio.h>
#include <string.h>
#include <stdlib.h>

char* f (char *s, int n) {
	int len,i,j, br=0;
	char *poruka;
	len = strlen(s);
	poruka = (char*) malloc(n*len*sizeof(char)+sizeof(char));  //ovaj +sizeofchar je '\0'
	for (i=0; i<n; i++){
		for(j=0; j<len; j++){
			poruka[br]=s[j];
			br++;
		}
	}
	poruka[br]='\0';
	return poruka;
}


int main() {
	char *p = "bla";
	char *n=NULL;
	n = f(p, 3);
	printf("%s", n);
	return 0;
}