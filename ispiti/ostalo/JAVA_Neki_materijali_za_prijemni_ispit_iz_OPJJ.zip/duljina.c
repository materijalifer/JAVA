#include <stdio.h>


int dulj(char *niz) {
	if (*niz=='\0') return 0;
	return 1+dulj(niz+1);
}

int main(int argc, char *argv[]){
	char *niz = argv[1];
	printf("%d\n", dulj(niz));
	return 0;
}