#include <stdio.h>
#include <stdlib.h>

int fibonacci(int n) {
	int a1 = 1;
	int a2 = 1;
	int i,j;
	if (n<1) {
		printf("Greska.");
		exit(1);
	}
	if (n==1 || n==2) return 1;
	for (i=3; i<=n; i++){
		j = a1+a2;
		a1=a2;
		a2=j;
	}
	return a2;
}


int main(int argc, char *argv[]){
	int broj;
	char *niz;
	niz = argv[1];
	broj = atoi(niz);
	printf("Fibonaccijev broj za clan %d je %d\n", broj, fibonacci(broj));
	return 0;
}