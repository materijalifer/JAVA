#include <stdio.h>
#include <stdlib.h>

int prim_broj(int n) {
	int brojac=2;
	int broj=3;
	int i, flag=0;
	if (n==1)
		return 1;
	if (n==2) 
		return 2;
	while (brojac<n){
		flag=0;
		for (i=2; i<broj; i++){
			if (broj%i==0){
				flag=1;
				break;
			}
		}
		if (!flag){
			brojac++;
		}
		if (brojac<n)
			broj++;
	}
	return broj;
}

int main(int argc, char *argv[]) {
	int broj, prosti;
	broj = atoi(argv[1]);
	printf("%d\n", broj);
	prosti=prim_broj(broj);
	printf("%d-ti prosti broj je: %d\n", broj, prosti);
	return 0;
}