#include <stdio.h>
#include <stdlib.h>

int main (int argc, char *argv[]) {
	int d;
	char prezime[20];
	char c;
	FILE *file, *ispis;
	file = fopen("C:/Users/User/Desktop/daniel_mapa/FER/JAVA_PRIJEMNI/tekst.txt", "r");
	ispis = fopen("ispis.txt", "w");
	if (file==NULL){
		printf("bla\n");
		exit(1);
	}
	while (fscanf(file, "%d%s", &d, prezime)==2){
		fprintf(ispis,"%s %d\n", prezime,d);
	}
	fclose(file);
	fclose(ispis);
	return 0;
}