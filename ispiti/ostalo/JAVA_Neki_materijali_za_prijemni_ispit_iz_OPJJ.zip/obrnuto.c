#include <stdio.h>
#include <stdlib.h>
#include <string.h>


int main (int argc, char *argv[]){
	int i, j;
	int n;
	char *rijec;
	for (i = argc-1; i>0; i--){
		n = strlen(argv[i]);
		rijec = argv[i];

		for (j=n-1; j>=0; j--){
			printf("%c", rijec[j]);
		}
		if (i>1)
			printf(" ");
		else
			printf("\n");
	}
	return 0;

}