#include <stdio.h>
#include <stdlib.h>

int parni(char *niz){
	int broj = *niz-48;
	if (*niz=='\0') return 0;
	if (broj%2==0) return 1+parni(niz+1);
	else return 0+parni(niz+1);
}


int main (void) {
	char *niz = "2985642";

	printf("Broj parnih je %d\n", parni(niz));
	return 0;
}
