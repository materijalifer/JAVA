#include <stdio.h>


void broj (int *el){
	*el = 3;
}

int main() {
	int a = 4;
	int *b=&a;

	broj(b);
	printf("%d\n", *b);

	return 0;
}