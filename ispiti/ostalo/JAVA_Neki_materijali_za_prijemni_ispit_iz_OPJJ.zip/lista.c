#include <stdio.h>
#include <stdlib.h>

typedef struct {
	int matbr;
	char imeprez[25];
	float ocjena;
} struktura;

struct at {
	struktura element;
	struct at *sljed;
};

typedef struct at atom;

void ispisi (atom *glava) {
	atom *pom;
	struktura pomocna;
	for (pom = glava; pom!=NULL; pom=pom->sljed){
		pomocna = pom->element;
		printf("%8d %s %10f\n", pomocna.matbr, pomocna.imeprez, pomocna.ocjena);
	}
}

int main (void) {
	FILE *f;
	atom *glava=NULL;
	atom *p=NULL;
	atom *novi=NULL;
	struktura strukt;
	f = fopen("lista.txt", "r");

	while ( fscanf(f, "%8d %20[^\n] %10f", &strukt.matbr, strukt.imeprez, &strukt.ocjena)==3){
		if (glava==NULL){
			glava = (atom*) malloc(sizeof(atom));
			glava->element=strukt;
			glava->sljed=NULL;
			p=glava;
		}
		else {
			novi = (atom *) malloc(sizeof(atom));
			novi->element = strukt;
			novi->sljed = NULL;
			p->sljed = novi;
			p=novi;
		}
	}
	ispisi(glava);
	return 0;
}