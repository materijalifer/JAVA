#include <stdio.h>
#include <stdlib.h>

typedef struct cv {
	int el;
	struct cv *lijevo;
	struct cv *desno;
} cvor;


cvor *dodaj(cvor *korijen, int broj) {
	if (korijen==NULL) {
		korijen = (cvor *) malloc(sizeof(cvor));
		if (korijen==NULL) return NULL;
		korijen->el = broj;
		korijen->lijevo=NULL;
		korijen->desno=NULL;
	}
	else if (broj>=korijen->el){
		korijen->lijevo = dodaj(korijen->lijevo, broj);
	}
	else
		korijen->desno = dodaj(korijen->desno, broj);
	return korijen;
}

int zamijeni (cvor *korijen) {
	int pom;
	if (korijen==NULL) return 0;
	pom = korijen->el;
	korijen->el = zamijeni(korijen->lijevo) + zamijeni(korijen->desno);
	pom+=korijen->el;
	return pom;
}

void inorder(cvor *korijen) {
	if (korijen==NULL) return;
	inorder(korijen->lijevo);
	printf("%d ", korijen->el);
	inorder(korijen->desno);
}


int main (void) {
	int polje[10]={2,5,1,7,4,8,7,2,3,11};
	int i;
	cvor *korijen=NULL;
	for (i=0; i<10; i++){
		korijen=dodaj(korijen, polje[i]);
	}

	inorder(korijen);
	zamijeni(korijen);
	printf("\n");
	inorder(korijen);
	return 0;
}