#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>

struct at {
	int element;
	struct at * sljed;
};

typedef struct at atom;

int dodaj (int element, atom **ulaz, atom **izlaz) {
	atom *novi;
	novi = (atom *)malloc(sizeof(atom*));
	if (novi==NULL) return 0;

	novi->element = element;
	novi->sljed=NULL;

	if (*izlaz==NULL){
		*izlaz=novi;
		izlaz->sljed=NULL;
	}
	else {
		(*ulaz)->sljed=novi;
	}
	*ulaz = novi;
	return 1;
}