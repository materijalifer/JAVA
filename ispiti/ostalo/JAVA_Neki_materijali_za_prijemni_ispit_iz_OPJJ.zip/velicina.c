#include <stdio.h>

int vel_niz(char *niz){
	if (*niz=='\0') return 0;
	else return 1+vel_niz(niz+1);
}

int main (int argc, char* argv[]){
	char *rijec = argv[1];
	printf("%d", vel_niz(rijec));
	return 0;
}
