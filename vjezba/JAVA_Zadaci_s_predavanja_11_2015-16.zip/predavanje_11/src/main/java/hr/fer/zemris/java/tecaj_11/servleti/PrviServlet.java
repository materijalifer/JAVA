package hr.fer.zemris.java.tecaj_11.servleti;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class PrviServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		resp.setContentType("text/html; charset=UTF-8");
		PrintWriter out = resp.getWriter();
		
		out.write("<html><body>");
		out.write("<h1>Naša prva web-stranica iz servleta</h1>");
		out.write("<p>Dobrodošli u našu prvu web-stranicu!!!</p>");
		out.write("</body></html>");
	}
	
}
