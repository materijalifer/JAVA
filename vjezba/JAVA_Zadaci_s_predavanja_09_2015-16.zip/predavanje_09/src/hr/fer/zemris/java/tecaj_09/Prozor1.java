package hr.fer.zemris.java.tecaj_09;

import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.SwingUtilities;
import javax.swing.WindowConstants;

/**
 * Primjer koji demonstrira kako ne zatvoriti prozor nego pitati korisnika što
 * želi.
 * <p>
 * Problem je u tome što ne trebamo OTKAZATI zatvaranje prozora, nego nad
 * prozorom treba registrirati WindowListener, u sljedećim koracima:
 * <ol>
 * <li>POSTAVITI defaultCloseOperation na DO_NOTHING_ON_CLOSE
 * <li>REGISTRIRATI WindowListener i u metodi onWindowClosing(...) napraviti
 * provjeru
 * <li>POZVATI dispose()
 * </ol>
 */
public class Prozor1 extends JFrame {
	private static final long serialVersionUID = -4811984031975354008L;

	public Prozor1() {
		setDefaultCloseOperation(WindowConstants.DO_NOTHING_ON_CLOSE);
		setLocation(100, 100);
		setSize(300, 300);
		
		// iz razreda Window. Umjesto new WindowListener radimo WindowAdapter
		addWindowListener(new WindowAdapter() {
			@Override
			public void windowClosing(WindowEvent e) {
				int odluka = JOptionPane.showConfirmDialog(
					Prozor1.this,
					"Jeste li sigurni da želite zatvoriti prozor?",
					"Poruka sustava",
					JOptionPane.YES_NO_OPTION);
				
				if (odluka != JOptionPane.YES_OPTION) return;
				dispose();
			}
		});
	}

	public static void main(String[] args) {
		SwingUtilities.invokeLater(() -> {
			new Prozor1().setVisible(true);
		});
	}
	
}
