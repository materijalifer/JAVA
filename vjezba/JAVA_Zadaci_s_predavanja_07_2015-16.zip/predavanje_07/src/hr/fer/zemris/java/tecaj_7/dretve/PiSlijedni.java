package hr.fer.zemris.java.tecaj_7.dretve;

import java.util.Random;

public class PiSlijedni {

	public static void main(String[] args) {
		final int NUMBER_OF_SAMPLES = 10_000_000;
		
		double pi = izracunaj(NUMBER_OF_SAMPLES);
		
		System.out.println(pi);
	}

	private static double izracunaj(int numberOfSamples) {
		int inside = PiUtil.testNumberOfTimesInCircle(numberOfSamples, new Random());
		return 4.0 * inside / numberOfSamples;
	}
	
}
