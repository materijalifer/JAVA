package hr.fer.zemris.java.tecaj_7.dretve;

import java.util.Random;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

public class PiParalelni4 {

	public static void main(String[] args) {
		final int NUMBER_OF_SAMPLES = 10_000_000;
		
		ExecutorService pool = Executors.newFixedThreadPool(2);
		
		double pi = izracunaj(NUMBER_OF_SAMPLES, pool);
		
		System.out.println("PI iznosi: " + pi);
		
		pool.shutdown();
	}

	private static double izracunaj(int numberOfSamples, ExecutorService pool) {
		class Posao implements Runnable {
			int inside;
			int samples;
			
			public Posao(int samples) {
				this.samples = samples;
			}
			
			@Override
			public void run() {
				inside = PiUtil.testNumberOfTimesInCircle(samples, new Random());
			}
		}
		
		Posao p1 = new Posao(numberOfSamples/2);
		Posao p2 = new Posao(numberOfSamples - numberOfSamples/2);
		
		Future<?> status1 = pool.submit(p1);
		Future<?> status2 = pool.submit(p2);
		
		while (true) {
			try {
				status1.get();
				break;
			} catch (Exception ignorable) {}
		}
		while (true) {
			try {
				status2.get();
				break;
			} catch (Exception ignorable) {}
		}
		
		return 4.0 * (p1.inside+p2.inside) / numberOfSamples;
	}
	
}
