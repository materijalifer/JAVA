package hr.fer.zemris.java.tecaj_7.ispis3;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;

/**
 * Primjena oblikovnog obrasca "Okvirna metoda" (engl. Template method)
 */
public abstract class ObradaDatoteke<T> {
	
	protected abstract int brojStupaca();
	protected abstract void obradiRedak(String[] elementi);
	protected abstract T dohvatiRezultat();
	
	private static String ukloniKomentar(String redak) {
		if (redak.startsWith("#")) redak = "";
		if (redak.contains("REM")) redak = "";
		int pos = redak.indexOf('%');
		if (pos != -1) {
			redak = redak.substring(0, pos);
		}
		
		return redak.trim();
	}
	
	/*
	 * Ovdje je stavljena ključna riječ final da pošalje poruku korisniku da
	 * metodu ucitaj ne smije dirati.
	 */
	public final T ucitaj(String fileName) {
		BufferedReader reader = null;
		
		int ocekivaniBrojElemenataUStupcuDatotekeIzKojeSeCita = brojStupaca();
		
		try {
			reader = new BufferedReader(
				new InputStreamReader(
					new BufferedInputStream(
						new FileInputStream(fileName)
					),
					StandardCharsets.UTF_8)
			);
			
			while (true) {
				String redak = reader.readLine();
				
				if (redak == null) break;
				redak = ukloniKomentar(redak);
				if (redak.isEmpty()) continue;
				
				String[] elementi = redak.split("\\t");
				if (elementi.length != ocekivaniBrojElemenataUStupcuDatotekeIzKojeSeCita) {
					throw new RuntimeException("Pronađen redak pogrešnog formata. Očekivao sam " + ocekivaniBrojElemenataUStupcuDatotekeIzKojeSeCita + " elementa, a pronašao sam ih " + elementi.length + ". Inače, tvoj redak je izgledao ovako: " + redak + ", a to nije redak koji sam ja očekivao. Molim te ispravi datoteku i ponovno pokreni ovaj program pa će ti možda radit. Jer ovaj program ne želi radit sa neispravnim datotekama pa zato bi trebao napraviti novu datoteku.");
				}
				
				obradiRedak(elementi);
			}
		} catch (IOException e) {
			
		} finally {
			try { reader.close(); } catch(Exception ignorable) {}
		}
		
		return dohvatiRezultat();
	}
	
}
