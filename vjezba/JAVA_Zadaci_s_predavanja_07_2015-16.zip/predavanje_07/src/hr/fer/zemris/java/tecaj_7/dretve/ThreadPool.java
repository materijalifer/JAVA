package hr.fer.zemris.java.tecaj_7.dretve;

import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;

/**
 * Thread poisoning.
 */
public class ThreadPool {

	private static final Runnable RED_PILL = () -> {};
	
	private BlockingQueue<JobInfo> jobs = new LinkedBlockingQueue<>();
	private Thread[] workers;
	
	public ThreadPool() {
		this(Runtime.getRuntime().availableProcessors());
	}
	
	public ThreadPool(int numberOfWorkers) {
		workers = new Thread[numberOfWorkers];
		for (int i = 0; i < workers.length; i++) {
			workers[i] = new Thread(() -> {
				while (true) {
					JobInfo jobInfo = nextJob();
					if (jobInfo.job == RED_PILL) break;
					try {
						jobInfo.job.run();
					} finally {
						jobInfo.markExecuted();
					}
				}
			});
			workers[i].start();
		}
	}
	
	public void shutdown() {
		for (int i = 0; i < workers.length; i++) {
			addJob(RED_PILL);
		}
	}

	private JobInfo nextJob() {
		while (true) {
			try {
				return jobs.take();
			} catch (InterruptedException ignorable) {}
		}
	}
	
	public JobInfo addJob(Runnable job) {
		JobInfo jobInfo = new JobInfo(job);
		while (true) {
			try {
				jobs.put(jobInfo);
				return jobInfo;
			} catch (InterruptedException ignorable) {}
		}
	}
	
	public static class JobInfo {
		private volatile boolean executed;
		private Runnable job;
		
		public JobInfo(Runnable job) {
			this.job = job;
		}
		
		private synchronized void markExecuted() {
			executed = true;
			notifyAll();
		}
		
		public synchronized void waitUntilJobIsExecuted() {
//			while (!executed); // jako loše rješenje
			while (!executed) {
				try { wait(); } catch (InterruptedException ignorable) {}
			}
		}
	}
	
}
