package hr.fer.zemris.java.tecaj_7.dretve;

import java.util.Random;

public class PiParalelni1 {

	public static void main(String[] args) {
		final int NUMBER_OF_SAMPLES = 10_000_000;
		
		double pi = izracunaj(NUMBER_OF_SAMPLES);
		
		System.out.println("PI iznosi: " + pi);
	}

	private static double izracunaj(int numberOfSamples) {
		class Posao implements Runnable {
			int inside;
			int samples;
			
			public Posao(int samples) {
				this.samples = samples;
			}
			
			@Override
			public void run() {
				inside = PiUtil.testNumberOfTimesInCircle(samples, new Random());
			}
		}
		
		Posao p1 = new Posao(numberOfSamples/2);
		Posao p2 = new Posao(numberOfSamples - numberOfSamples/2);
		
		Thread t1 = new Thread(p1);
		Thread t2 = new Thread(p2);
		
		t1.start();
		t2.start();
		
		sacekajDretve(t1, t2);
		
		return 4.0 * (p1.inside+p2.inside) / numberOfSamples;
	}

	private static void sacekajDretve(Thread t1, Thread t2) {
		while (true) {
			try {
				t1.join();
				break;
			} catch (InterruptedException ignorable) {}
		}
		while (true) {
			try {
				t2.join();
				break;
			} catch (InterruptedException ignorable) {}
		}
	}
	
}
