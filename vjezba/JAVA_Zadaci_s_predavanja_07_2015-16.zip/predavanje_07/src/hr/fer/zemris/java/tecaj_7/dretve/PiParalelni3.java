package hr.fer.zemris.java.tecaj_7.dretve;

import java.util.Random;

import hr.fer.zemris.java.tecaj_7.dretve.ThreadPool.JobInfo;

public class PiParalelni3 {

	public static void main(String[] args) {
		final int NUMBER_OF_SAMPLES = 10_000_000;
		
		ThreadPool pool = new ThreadPool(1);
		
		double pi = izracunaj(NUMBER_OF_SAMPLES, pool);
		
		System.out.println("PI iznosi: " + pi);
		
		pool.shutdown();
	}

	private static double izracunaj(int numberOfSamples, ThreadPool pool) {
		class Posao implements Runnable {
			int inside;
			int samples;
			
			public Posao(int samples) {
				this.samples = samples;
			}
			
			@Override
			public void run() {
				inside = PiUtil.testNumberOfTimesInCircle(samples, new Random());
			}
		}
		
		Posao p1 = new Posao(numberOfSamples/2);
		Posao p2 = new Posao(numberOfSamples - numberOfSamples/2);
		
		pool.addJob(p1);
		pool.addJob(p2);
		
		JobInfo status1 = pool.addJob(p1);
		JobInfo status2 = pool.addJob(p2);
		
		status1.waitUntilJobIsExecuted();
		status2.waitUntilJobIsExecuted();
		
		return 4.0 * (p1.inside+p2.inside) / numberOfSamples;
	}
	
}
