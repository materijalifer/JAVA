package hr.fer.zemris.java.tecaj.p04;

import java.util.Iterator;
import java.util.NoSuchElementException;

public class SlijedParnihBrojeva implements Iterable<Integer> {

	private final int prvi;
	private final int ukupno;
	
	public SlijedParnihBrojeva(int prvi, int ukupno) {
		super();
		if (prvi % 2 != 0) {
			throw new IllegalArgumentException("");
		}
		if (ukupno < 1) {
			throw new IllegalArgumentException("Broj elemenata mora biti barem jedan. Traženo je " + ukupno + ".");
		}
		this.prvi = prvi;
		this.ukupno = ukupno;
	}
	
	public Iterator<Integer> iterator() {
		return new MojIterator();
	}
	
	private class MojIterator implements Iterator<Integer> {
		
		private int trenutni = prvi;
		private int preostalo = ukupno;
		
		@Override
		public boolean hasNext() {
			return preostalo > 0;
		}
		@Override
		public Integer next() {
			if (!hasNext()) {
				throw new NoSuchElementException();
			};
			
			int vrati = trenutni;
			trenutni += 2;
			preostalo--;
			
			return vrati;
		}
		
	}
	
}
