package hr.fer.zemris.java.tecaj.p04;

import java.util.Iterator;

public class Demonstracija {

	public static void main(String[] args) {
		SlijedParnihBrojeva spb = new SlijedParnihBrojeva(0, 10);
		
		Iterator<Integer> it = spb.iterator();
		while (it.hasNext()) {
			System.out.print(it.next() + " ");
		}
		System.out.println();
		
		for (Integer i : spb) {
			System.out.print(i + " ");
		}
	}
	
}
