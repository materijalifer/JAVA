package hr.fer.zemris.java.tecaj.p3c0;

public class Storage {

	@SuppressWarnings("unused")
	private double value;

	public Storage(double value) {
		this.value = value;
	}
	
	public void setValue(double value) {
		this.value = value;
	}
	
	public ValueProvider getValueProvider() {
		return null;
	}
	
}
