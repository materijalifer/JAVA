package hr.fer.zemris.java.tecaj.p3d;

public class Demonstration {

	static interface Funkcija {
		
		double valueAt(double x);
		
	}
	
	public static class Kvadriraj implements Funkcija {
		@Override
		public double valueAt(double x) {
			return x*x;
		}
	}
	
	public static class Korjenuj implements Funkcija {
		@Override
		public double valueAt(double x) {
			return Math.sqrt(x);
		}
	}
	
	public static void main(String[] args) {
		double[] brojevi = {
				1.0, 3.14, 2.71, 9, 16
		};
		
//		ispisi(brojevi, new Kvadriraj());
		
//		Funkcija f = new Funkcija() {
//			@Override
//			public double valueAt(double x) {
//				return (x+1)*(x+1);
//			}
//		};
//		ispisi(brojevi, f);
		
//		Funkcija f2 = (double x) -> { return (x+1)*(x+1); };
//		ispisi(brojevi, f2);
		
//		Funkcija f3 = (x) -> { return (x+1)*(x+1); };
//		ispisi(brojevi, f3);
		
//		Funkcija f4 = x -> { return (x+1)*(x+1); };
//		ispisi(brojevi, f4);
		
//		Funkcija f5 = x -> (x+1)*(x+1);
//		ispisi(brojevi, f5);
		
//		Funkcija f6 = x -> Math.sqrt(x);
//		ispisi(brojevi, f6);
		
		Funkcija f7 = Math::sqrt;
		ispisi(brojevi, f7);
	}

	private static void ispisi(double[] brojevi, Funkcija f) {
		for (double broj : brojevi) {
			double rez = f.valueAt(broj);
			System.out.printf("f(%f) = %f%n", broj, rez);
		}
	}
	
}
