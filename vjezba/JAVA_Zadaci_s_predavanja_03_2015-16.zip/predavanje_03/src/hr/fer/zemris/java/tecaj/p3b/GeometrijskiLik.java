package hr.fer.zemris.java.tecaj.p3b;

public abstract class GeometrijskiLik implements SadrziocTocaka {
	
}