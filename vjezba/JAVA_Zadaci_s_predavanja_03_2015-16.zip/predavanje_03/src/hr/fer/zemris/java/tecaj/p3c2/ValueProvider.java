package hr.fer.zemris.java.tecaj.p3c2;

public interface ValueProvider {

	double getValue();
	double getSquared();
	double getSquareRoot();
	
}
