package hr.fer.zemris.java.tecaj.p3c0;

public interface ValueProvider {

	double getValue();
	double getSquared();
	double getSquareRoot();
	
}
