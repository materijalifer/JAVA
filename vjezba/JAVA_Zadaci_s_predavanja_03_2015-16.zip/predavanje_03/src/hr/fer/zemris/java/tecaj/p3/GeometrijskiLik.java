package hr.fer.zemris.java.tecaj.p3;

import hr.fer.zemris.java.tecaj_3.prikaz.Slika;

public abstract class GeometrijskiLik {

	public abstract boolean sadrziTocku(int x, int y);
	
	public void popuniLik(Slika slika) {
		int ymax = slika.getVisina();
		int xmax = slika.getSirina();
		
		for (int y = 0; y < ymax; y++) {
			for (int x = 0; x < xmax; x++) {
				if (this.sadrziTocku(x, y)) {
					slika.upaliTocku(x, y);
				}
			}
		}
	}
	
}