package hr.fer.zemris.java.tecaj.p3b;

public class Pravokutnik extends GeometrijskiLik {
	
	private int x;
	private int y;
	private int w;
	private int h;
	
	public Pravokutnik(int x, int y, int w, int h) {
		super();
		this.x = x;
		this.y = y;
		this.w = w;
		this.h = h;
	}

	@Override
	public boolean sadrziTocku(int x, int y) {
		if (x < this.x) return false;
		if (y < this.y) return false;
		if (x >= this.x+w) return false;
		if (y >= this.y+h) return false;

		return true;
	}
	
//	@Override
//	public void popuniLik(Slika slika) {
//		int y = this.y < 0 ? 0:this.y;
//		int x = this.x < 0 ? 0:this.x;
//		
//		for (int ymax = this.y+this.h; y < ymax; y++) {
//			for (int xmax = this.x + this.w; x < xmax; x++) {
//				slika.upaliTocku(x, y);
//			}
//		}
//	}

}
