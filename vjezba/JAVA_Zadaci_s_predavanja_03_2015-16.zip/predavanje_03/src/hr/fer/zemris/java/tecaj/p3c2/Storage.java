package hr.fer.zemris.java.tecaj.p3c2;

public class Storage {

	private double value;

	public Storage(double value) {
		this.value = value;
	}
	
	public void setValue(double value) {
		this.value = value;
	}
	
	public ValueProvider getValueProvider() {
		return new ValueProviderImpl();
	}
	
	/*
	 * ako je ovaj razred definiran kao nestatički razred, onda će kompajler za
	 * vas odrediti jedan dio magije: kompajler će za vas reći:
	 * razred ValueProviderImpl ima članske varijable:
	 * x Storage.this
	 * 
	 * Kompajler će za nas deklarirati te varijable, proširit će konstruktor i
	 * inicijalizirat će te varijable.
	 */
	private class ValueProviderImpl implements ValueProvider {

		@Override
		public double getValue() {
			return Storage.this.value;
		}

		@Override
		public double getSquared() {
			return value*value;
		}

		@Override
		public double getSquareRoot() {
			return Math.sqrt(value);
		}
		
	}
	
}
