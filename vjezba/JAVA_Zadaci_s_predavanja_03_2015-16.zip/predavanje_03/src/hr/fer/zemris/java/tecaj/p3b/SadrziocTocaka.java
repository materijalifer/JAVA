package hr.fer.zemris.java.tecaj.p3b;

public interface SadrziocTocaka {
	
	boolean sadrziTocku(int x, int y);

}
