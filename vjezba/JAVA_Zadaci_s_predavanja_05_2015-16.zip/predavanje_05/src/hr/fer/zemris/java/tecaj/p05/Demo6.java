package hr.fer.zemris.java.tecaj.p05;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@SuppressWarnings("unused")
public class Demo6 {

	private static class Zaposlenik {
		private String ime;
		private String prezime;
		private String sifra;
		private Integer ocjena;
		
		public Zaposlenik(String ime, String prezime, String sifra, Integer ocjena) {
			super();
			this.ime = ime;
			this.prezime = prezime;
			this.sifra = sifra;
			this.ocjena = ocjena;
		}
		
		public String getIme() {
			return ime;
		}
		
		public String getPrezime() {
			return prezime;
		}
		
		public String getSifra() {
			return sifra;
		}
		
		@Override
		public String toString() {
			return String.format("(%s) %s, %s, ocjena: %d", sifra, prezime, ime, ocjena);
		}

		@Override
		public boolean equals(Object obj) {
			if (!(obj instanceof Zaposlenik)) return false;
			Zaposlenik drugi = (Zaposlenik) obj;
			return this.sifra.equals(drugi.sifra);
		}
	}
	
	public static void main(String[] args) {
		List<Zaposlenik> lista = new ArrayList<>();

		lista.add(new Zaposlenik("Janko", "Jankić", "0001", 1));
		lista.add(new Zaposlenik("Anica", "Anić", "0002", 5));
		lista.add(new Zaposlenik("Zdravko", "Zdravkić", "0003", 5));
		lista.add(new Zaposlenik("Bojan", "Bojanić", "0004", 3));
		lista.add(new Zaposlenik("Stjepan", "Stjepanić", "0005", 2));
		lista.add(new Zaposlenik("Jasmina", "Jasminić", "0006", 3));
		lista.add(new Zaposlenik("Ivana", "Ivanić", "0007", 1));
		
		lista.stream().forEach(System.out::println);
		System.out.println("************************************");
		
		lista.stream().filter(z -> z.ocjena > 1).forEach(System.out::println);
		System.out.println("************************************");
		
		lista.stream()
			.filter(z -> z.ocjena > 1)
			.sorted((z1, z2) -> z1.ocjena.compareTo(z2.ocjena))
			.forEach(System.out::println);
		System.out.println("************************************");
		
		lista.stream()
			.filter(z -> z.ocjena > 1)
			.sorted((z1, z2) -> z1.ocjena.compareTo(z2.ocjena))
			.map(z -> z.getSifra())
			.forEach(System.out::println);
		System.out.println("************************************");
		
		List<String> sifre = lista.stream()
				.filter(z -> z.ocjena > 1)
				.sorted((z1, z2) -> z1.ocjena.compareTo(z2.ocjena))
				.map(z -> z.getSifra())
				.collect(Collectors.toList());
		
		System.out.println(sifre);
	}
	
}
