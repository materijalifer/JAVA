package hr.fer.zemris.java.tecaj.p05;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

@SuppressWarnings("unused")
public class Demo4 {

	/**
	 * Zaposlenik.
	 *
	 * @author dinomario10
	 */
	private static class Zaposlenik implements Comparable<Zaposlenik> {
		private String ime;
		private String prezime;
		private String sifra;
		
		private static final Comparator<Zaposlenik> PO_IMENU =
				(z1, z2) -> z1.ime.compareTo(z2.ime);
				
		private static final Comparator<Zaposlenik> PO_PREZIMENU =
				(z1, z2) -> z1.prezime.compareTo(z2.prezime);
				
		private static final Comparator<Zaposlenik> PO_SIFRI =
				(z1, z2) -> z1.sifra.compareTo(z2.sifra);
		
		public Zaposlenik(String ime, String prezime, String sifra) {
			super();
			this.ime = ime;
			this.prezime = prezime;
			this.sifra = sifra;
		}
		
		public String getIme() {
			return ime;
		}
		
		public String getPrezime() {
			return prezime;
		}
		
		public String getSifra() {
			return sifra;
		}
		
		@Override
		public String toString() {
			return String.format("(%s) %s, %s", sifra, prezime, ime);
		}
		
		@Override
		public int compareTo(Zaposlenik drugi) {
			return -sifra.compareTo(drugi.sifra);
		}

		@Override
		public boolean equals(Object obj) {
			if (!(obj instanceof Zaposlenik)) return false;
			Zaposlenik drugi = (Zaposlenik) obj;
			return this.sifra.equals(drugi.sifra);
		}
	}
	
	/**
	 * Komparator po siframa.
	 * 
	 * @author dinomario10
	 */
	private static class MojKomparator implements Comparator<Zaposlenik> {
		@Override
		public int compare(Zaposlenik z1, Zaposlenik z2) {
			return z1.sifra.compareTo(z2.sifra);
		}
	}
	
	/**
	 * Komparator po imenima.
	 *
	 * @author dinomario10
	 */
	private static class PoImenima implements Comparator<Zaposlenik> {
		@Override
		public int compare(Zaposlenik z1, Zaposlenik z2) {
			return z1.ime.compareTo(z2.ime);
		}
	}
	
	/**
	 * Ulazna točka programa.
	 */
	public static void main(String[] args) {
		Set<Zaposlenik> skup = new TreeSet<>(
				Zaposlenik.PO_IMENU.reversed()
				.thenComparing(Zaposlenik.PO_SIFRI.reversed())
		);

		skup.add(new Zaposlenik("Janko", "Jankić", "0001"));
		skup.add(new Zaposlenik("Anica", "Anić", "0002"));
		skup.add(new Zaposlenik("Zdravko", "Zdravkić", "0003"));
		skup.add(new Zaposlenik("Bojan", "Bojanić", "0004"));
		skup.add(new Zaposlenik("Stjepan", "Stjepanić", "0005"));
		skup.add(new Zaposlenik("Jasmina", "Jasminić", "0006"));
		skup.add(new Zaposlenik("Ivana", "Ivanić", "0007"));
		skup.add(new Zaposlenik("Ivana", "Anić", "0008"));
		
		Zaposlenik z2 = new Zaposlenik("Zdravko", "Zdravkić", "0003");
		
		System.out.println("Zaposlenik " + z2 + " je prisutan: " + skup.contains(z2));
		
		skup.forEach(System.out::println);
	}
	
}
