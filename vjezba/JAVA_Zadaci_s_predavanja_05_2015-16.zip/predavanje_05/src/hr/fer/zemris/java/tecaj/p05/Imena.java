package hr.fer.zemris.java.tecaj.p05;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.HashMap;
import java.util.Map;

public class Imena {

	public static void main(String[] args) throws IOException {
		BufferedReader reader = new BufferedReader(
				new InputStreamReader(System.in)
		);
		
		Map<String, Integer> imena = new HashMap<>();
		while (true) {
			String redak = reader.readLine();
			if (redak == null) break;
			
			redak = redak.trim();
			if (redak.isEmpty()) continue;
			
			if (redak.equals("quit")) break;
			
			Integer trenutni = imena.get(redak);
			if (trenutni == null) {
				trenutni = 1;
			} else {
				trenutni += 1;
			}
			
			imena.put(redak, trenutni);
		}
		
		reader.close();
		
		// Glupo smrdljivo rjesenje
		for (String ime : imena.keySet()) {
			Integer broj = imena.get(ime);
			System.out.println(ime + " => " + broj);
		}
		
		System.out.println();
		
		// Puno bolje rjesenje
		for (Map.Entry<String, Integer> par : imena.entrySet()) {
			System.out.println(par.getKey() + " => " + par.getValue());
		}
		
		System.out.println();
		
		// Ma jos bolje rjesenje
		imena.forEach((ime, ocjena) -> System.out.println(ime + " => " + ocjena));
		
		System.out.println();
		
		// Za vjezbu
		imena.entrySet().forEach((e) -> System.out.println(e.getKey() + " => " + e.getValue()));
	}

}
