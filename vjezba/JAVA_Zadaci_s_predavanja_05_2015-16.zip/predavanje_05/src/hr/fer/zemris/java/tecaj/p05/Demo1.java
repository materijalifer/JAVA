package hr.fer.zemris.java.tecaj.p05;

import java.util.ArrayList;
import java.util.List;

@SuppressWarnings("unused")
public class Demo1 {

	private static class Zaposlenik {
		private String ime;
		private String prezime;
		private String sifra;
		
		public Zaposlenik(String ime, String prezime, String sifra) {
			super();
			this.ime = ime;
			this.prezime = prezime;
			this.sifra = sifra;
		}
		
		public String getIme() {
			return ime;
		}
		
		public String getPrezime() {
			return prezime;
		}
		
		public String getSifra() {
			return sifra;
		}
		
		@Override
		public String toString() {
			return String.format("(%s) %s, %s", sifra, prezime, ime);
		}

		@Override
		public boolean equals(Object obj) {
			if (!(obj instanceof Zaposlenik)) return false;
			Zaposlenik drugi = (Zaposlenik) obj;
			return this.sifra.equals(drugi.sifra);
		}
	}
	
	public static void main(String[] args) {
		List<Zaposlenik> lista = new ArrayList<>();

		lista.add(new Zaposlenik("Janko", "Jankić", "0001"));
		lista.add(new Zaposlenik("Anica", "Anić", "0002"));
		lista.add(new Zaposlenik("Zdravko", "Zdravkić", "0003"));
		lista.add(new Zaposlenik("Bojan", "Bojanić", "0004"));
		lista.add(new Zaposlenik("Stjepan", "Stjepanić", "0005"));
		lista.add(new Zaposlenik("Jasmina", "Jasminić", "0006"));
		lista.add(new Zaposlenik("Ivana", "Ivanić", "0007"));
		
		Zaposlenik z1 = lista.get(2);
		Zaposlenik z2 = new Zaposlenik("Zdravko", "Zdravkić", "0003");
		
		System.out.println("Zaposlenik " + z1 + " je prisutan: " + lista.contains(z1));
		System.out.println("Zaposlenik " + z2 + " je prisutan: " + lista.contains(z2));
	}
	
}
