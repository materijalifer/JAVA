package hr.fer.zemris.jmbag0036484942.cmdapps.JDBCPrimjeri;

/**
 * Hello world!
 */
public class App {
	
	public static void main(String[] args) {
		System.out.println("Hello World!");
	}

}
