package hr.fer.zemris.java.tecaj_1;

import hr.fer.zemris.java.poruke.Einstein;

public class Citati {

	public static void main(String[] args) {
		System.out.printf("Raspolažemo s %d citata.%n%n", Einstein.getQuotesCount());
		System.out.printf("Slučajan citat: %s.%n%n", Einstein.getRandomQuote());

		/* Ne koristiti ovu katastrofu */
//		for (int i = 0; i < Einstein.getQuotesCount(); i++) {
//			System.out.println(Einstein.getQuote(i));
//		}

		/* Bolje rješenje */
//		for (int i = 0, n = Einstein.getQuotesCount(); i < n; i++) {
//			System.out.println(Einstein.getQuote(i));
//		}

		for (String quote : Einstein.allQuotes()) {
			System.out.println(quote);
		}
	}

}