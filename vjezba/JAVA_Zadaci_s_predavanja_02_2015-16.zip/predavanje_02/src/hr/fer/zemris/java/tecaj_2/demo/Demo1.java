package hr.fer.zemris.java.tecaj_2.demo;

import hr.fer.zemris.java.tecaj_2.GeometrijskiLik;

public class Demo1 {

	public static void main(String[] args) {
		GeometrijskiLik lik1 = new GeometrijskiLik("Lick1");
		GeometrijskiLik lik2 = new GeometrijskiLik("Lick2");
		
		String ime = lik1.getIme();
		
		System.out.println("Ime = " + ime);
		System.out.println("Površina lika 2 = " + lik2.getPovrsina());
	}
	
}
