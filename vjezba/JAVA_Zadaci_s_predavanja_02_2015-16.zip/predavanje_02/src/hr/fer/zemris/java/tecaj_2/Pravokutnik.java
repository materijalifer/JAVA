package hr.fer.zemris.java.tecaj_2;

public class Pravokutnik extends GeometrijskiLik {

	private int vrhX;
	private int vrhY;
	private int širina;
	private int visina;
	
	public Pravokutnik(String ime, int vrhX, int vrhY, int širina, int visina) {
		super(ime);
		this.vrhX = vrhX;
		this.vrhY = vrhY;
		this.širina = širina;
		this.visina = visina;
	}

	@Override
	public double getPovrsina() {
		return širina*visina;
	}
	
	@Override
	public double getOpseg() {
		return 2 * (širina + visina);
	}
	
	public int getVrhX() {
		return vrhX;
	}

	public int getVrhY() {
		return vrhY;
	}

	public int getŠirina() {
		return širina;
	}

	public int getVisina() {
		return visina;
	}

}
