package hr.fer.zemris.java.tecaj_2.demo;

import hr.fer.zemris.java.tecaj_2.GeometrijskiLik;
import hr.fer.zemris.java.tecaj_2.Pravokutnik;

public class Demo2 {

	public static void main(String[] args) {
		Pravokutnik p1 = new Pravokutnik("Lik1", 1, 1, 5, 5);
		Pravokutnik p2 = p1;
		
		GeometrijskiLik l3 = p1;
		
		System.out.println("Porvšina od p1 je " + p1.getPovrsina());
		System.out.println("Porvšina od p2 je " + p2.getPovrsina());
		System.out.println("Porvšina od l3 je " + l3.getPovrsina());
		
		System.out.println("Ime od p2 je: " + p2.getIme());
		
		GeometrijskiLik l4 = new Pravokutnik("Lik4", 1, 1, 5, 5);
		System.out.println("Površina od l4 je " + l4.getPovrsina());
		
		System.out.printf("%d", 0/0);
	}

}
