package hr.fer.zemris.java.tecaj10.udp;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.SocketException;
import java.net.UnknownHostException;

/**
 * Klijent kojim se pristupa prof. Marku Čupiću na poslužitelj.
 */
public class UDPKlijentZaCupica {

	/**
	 * Ulazna točka programa.
	 * 
	 * @param args argumenti naredbenog retka
	 * @throws UnknownHostException ak se desi nepoznati-host iznimka
	 * @throws SocketException ak se desi socket iznimka
	 */
	public static void main(String[] args) throws UnknownHostException, SocketException {
		if (args.length != 3) {
			System.out.println("Očekivao sam host port string");
			return;
		}

		String hostname = args[0];
		int port = Integer.parseInt(args[1]);

		String string = args[2];

		// Pripremi podatke upita koje treba poslati:
		short duljina = (short) string.length();
		byte[] stringBytes = string.getBytes();
		
		byte[] podatci = new byte[stringBytes.length+2];
		ShortUtil.shortToBytes(duljina, podatci, 0);
		
		System.arraycopy(stringBytes, 0, podatci, 2, stringBytes.length);

		// Stvori pristupnu točku klijenta:
		DatagramSocket dSocket = new DatagramSocket();

		// Umetni podatke u paket i paketu postavi adresu i port poslužitelja
		DatagramPacket packet = new DatagramPacket(
			podatci, podatci.length
		);
		packet.setSocketAddress(new InetSocketAddress(
			InetAddress.getByName(hostname),
			port
		));
		
		
		
		
		// Postavi timeout od 4 sekunde na primitak odgovora:
		dSocket.setSoTimeout(4000);

		// Pošalji upit poslužitelju:
		System.out.println("Šaljem upit...");
		try {
			dSocket.send(packet);
		} catch (IOException e) {
			System.out.println("Ne mogu poslati upit.");
		}

		// Obavezno zatvori pristupnu točku:
		dSocket.close();
	}

}
