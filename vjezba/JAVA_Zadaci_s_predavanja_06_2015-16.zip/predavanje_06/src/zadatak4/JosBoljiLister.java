package zadatak4;

import java.io.IOException;
import java.nio.file.FileVisitResult;
import java.nio.file.FileVisitor;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.attribute.BasicFileAttributes;

public class JosBoljiLister {

	public static void main(String[] args) {
		if (args.length != 1) {
			System.err.println("Očekivao sam jedan argument: stazu do direktorija");
			return;
		}
		
		Path dir = Paths.get(args[0]);
		
		if (!Files.isDirectory(dir)) {
			System.err.println("Staza mora biti direktorij!");
			return;
		}
		
		try {
			Files.walkFileTree(dir, new Ispis());
		} catch (IOException e) {
			e.printStackTrace();
		}
	};
	
	private static class Ispis implements FileVisitor<Path> {
		
		private int level;

		@Override
		public FileVisitResult preVisitDirectory(Path dir, BasicFileAttributes attrs) throws IOException {
			print(dir);
			level++;
			return FileVisitResult.CONTINUE;
		}

		@Override
		public FileVisitResult visitFile(Path file, BasicFileAttributes attrs) throws IOException {
			print(file);
			return FileVisitResult.CONTINUE;
		}

		@Override
		public FileVisitResult visitFileFailed(Path file, IOException exc) throws IOException {
			return FileVisitResult.CONTINUE;
		}

		@Override
		public FileVisitResult postVisitDirectory(Path dir, IOException exc) throws IOException {
			level--;
			return FileVisitResult.CONTINUE;
		}
		
		private void print(Path path) {
			if (level == 0) {
				System.out.println(path.normalize().toAbsolutePath());
			} else {
				printSpaces(level);
				System.out.println(path.getFileName());
			}
		}
		
		private static void printSpaces(int amount) {
			System.out.printf("%" + (2*amount) + "s", "");
		}
		
	}
	
}
