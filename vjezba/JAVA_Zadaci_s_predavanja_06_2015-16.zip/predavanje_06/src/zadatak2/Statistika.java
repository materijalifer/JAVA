package zadatak2;

import java.io.File;
import java.util.HashMap;
import java.util.Map;

public class Statistika {

	public static void main(String[] args) {
		if (args.length != 1) {
			System.err.println("Očekivao sam jedan argument: stazu do direktorija");
			return;
		}
		
		File dir = new File(args[0]);
		
		if (!dir.isDirectory()) {
			System.err.println("Staza mora biti direktorij!");
			return;
		}
		
		Map<String, ExtensionInfo> stats = calcStatistics(dir);
		
		stats.values().stream()
			.sorted((s1, s2) -> Double.compare(s1.getAverageSize(), s2.getAverageSize()))
			.forEach((info) -> {
				System.out.printf(
					"%s: %d, %d, %f%n",
					info.getExtension(),
					info.getCount(),
					info.getTotalSize(),
					info.getAverageSize());
		});
		
//		List<ExtensionInfo> sortedStats = new ArrayList<>(stats.values());
//		Collections.sort(
//			sortedStats,
//			(s1, s2) -> Double.compare(s1.getAverageSize(), s2.getAverageSize())
//		);
//		
//		for (ExtensionInfo info : sortedStats) {
//			System.out.printf(
//				"%s: %d, %d, %f%n",
//				info.getExtension(),
//				info.getCount(),
//				info.getTotalSize(),
//				info.getAverageSize());
//		}
	}

	private static Map<String, ExtensionInfo> calcStatistics(File dir) {
		Map<String, ExtensionInfo> stats = new HashMap<>();
		recurse(dir, stats);
		return stats;
	}

	private static void recurse(File dir, Map<String, ExtensionInfo> stats) {
		File[] children = dir.listFiles();
		if (children == null) {
			return;
		}
		
		for (File child : children) {
			if (child.isFile()) {
				addToMap(child, stats);
			} else if (child.isDirectory()) {
				recurse(child, stats);
			}
		}
	}

	private static void addToMap(File file, Map<String, ExtensionInfo> stats) {
		String name = file.getName();
		
		int dotIndex = name.lastIndexOf('.');
		if (dotIndex < 1 || dotIndex == name.length()-1) {
			return;
		}
		
		String extension = name.substring(dotIndex+1).toLowerCase();
		
		ExtensionInfo info = stats.get(extension);
		if (info == null) {
			info = new ExtensionInfo(extension);
			stats.put(extension, info);
		}
		
		info.update(file.length());
	}
	
	private static class ExtensionInfo {
		private String extension;
		private long totalSize;
		private int count;
		
		public ExtensionInfo(String extension) {
			this.extension = extension;
		}

		public String getExtension() {
			return extension;
		}

		public long getTotalSize() {
			return totalSize;
		}

		public int getCount() {
			return count;
		}
		
		public double getAverageSize() {
			return (double) totalSize / count;
		}
		
		public void update(long size) {
			totalSize += size;
			count++;
		}
	}
	
}
