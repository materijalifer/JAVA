package zadatak5;

import java.io.BufferedOutputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;

public class PisanjeDatoteke {

	public static void main(String[] args) {
		String tekst = "Ankica i šiščevapčić";
		byte[] podaci = tekst.getBytes(StandardCharsets.UTF_8);
		
		String novi = new String(podaci, StandardCharsets.UTF_8);
		System.out.println(novi);
		
		OutputStream out = null;
		try {
			out = new BufferedOutputStream(new FileOutputStream("./datoteka.txt"));
			for (byte b : podaci) {
				out.write(b);
			}
		} catch (IOException e) {
			System.err.println(e.getMessage());
		} finally {
			if (out != null) {
				try { out.close(); } catch (IOException ignorable) {}
			}
		}
	}
	
}
