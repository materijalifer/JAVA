package zadatak3;

import java.io.File;

public class ObilazakStabla {

	public static void obidi(File dir, ObradaStabla o) {
		
		o.ulazimUDirektorij(dir);
		
		File[] children = dir.listFiles();
		if (children != null) {
			for (File child : children) {
				if (child.isFile()) {
					o.gledamDatoteku(child);
				} else if (child.isDirectory()) {
					obidi(child, o);
				}
			}
		}
		
		o.izlazimIzDirektorija(dir);
	}
	
}
