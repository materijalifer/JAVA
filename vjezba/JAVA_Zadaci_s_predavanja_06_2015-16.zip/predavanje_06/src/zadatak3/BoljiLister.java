package zadatak3;

import java.io.File;

public class BoljiLister {

	public static void main(String[] args) {
		if (args.length != 1) {
			System.err.println("Očekivao sam jedan argument: stazu do direktorija");
			return;
		}
		
		File dir = new File(args[0]);
		
		if (!dir.isDirectory()) {
			System.err.println("Staza mora biti direktorij!");
			return;
		}
		
		ObilazakStabla.obidi(dir, new Ispis());
	};
	
	private static class Ispis implements ObradaStabla {
		
		private int level;

		@Override
		public void ulazimUDirektorij(File dir) {
			print(dir);
			level++;
		}

		@Override
		public void izlazimIzDirektorija(File dir) {
			level--;
		}

		@Override
		public void gledamDatoteku(File file) {
			print(file);
		}
		
		private void print(File f) {
			if (level == 0) {
				System.out.println(f.getAbsolutePath());
			} else {
				printSpaces(level);
				System.out.println(f.getName());
			}
		}
		
		private static void printSpaces(int amount) {
			System.out.printf("%" + (2*amount) + "s", "");
		}
		
	}
	
}
