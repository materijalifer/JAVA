package zadatak3;

import java.io.File;

public interface ObradaStabla {

	void ulazimUDirektorij(File dir);
	
	void izlazimIzDirektorija(File dir);
	
	void gledamDatoteku(File file);
	
}
