package zadatak1;

import java.io.File;

public class Lister {

	public static void main(String[] args) {
		if (args.length != 1) {
			System.err.println("Očekivao sam jedan argument: stazu do direktorija");
			return;
		}
		
		File dir = new File(args[0]);
		
		if (!dir.isDirectory()) {
			System.err.println("Staza mora biti direktorij!");
			return;
		}
		
		printContentOf(dir, 0);
	}

	private static void printContentOf(File dir, int level) {
		print(dir, level);
		
		File[] children = dir.listFiles();
		if (children == null) {
			return;
		}
		
		for (File child : children) {
			if (child.isFile()) {
				print(child, level+1);
			} else if (child.isDirectory()) {
				printContentOf(child, level+1);
			}
		}
	}

	private static void print(File f, int level) {
		if (level == 0) {
			System.out.println(f.getAbsolutePath());
		} else {
			printSpaces(level);
			System.out.println(f.getName());
		}
		
	}

	private static void printSpaces(int amount) {
		System.out.printf("%" + (2*amount) + "s", "");
	}
	
}
