package hr.fer.zemris.tecaj.swing.p08;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Point;
import java.awt.Rectangle;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.ArrayList;
import java.util.List;

import javax.swing.BorderFactory;
import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.SwingUtilities;
import javax.swing.WindowConstants;

/**
 * Jadno riješeno, ali ipak nešto radi...
 */
public class Prozor1 extends JFrame {
	private static final long serialVersionUID = 1L;

	public Prozor1() {
		setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
		
		setTitle("Prozor1");
		setLocation(20, 20);
		setSize(500, 200);
		
		initGUI();
	}

	private void initGUI() {
		getContentPane().setLayout(null);
		
		final Crtanje komponenta1 = new Crtanje();
		komponenta1.setLocation(10, 10);
		komponenta1.setSize(400, 150);
		komponenta1.setBorder(BorderFactory.createLineBorder(Color.RED, 2));
		komponenta1.setOpaque(true);
		komponenta1.setBackground(Color.YELLOW);
		
		getContentPane().add(komponenta1);
		
		komponenta1.addMouseListener(new MouseListener() {
			
			@Override
			public void mouseReleased(MouseEvent e) {
				komponenta1.zavrsiCrtanje(e.getPoint());
			}
			
			@Override
			public void mousePressed(MouseEvent e) {
				komponenta1.zapocniCrtanje(e.getPoint());
			}
			
			@Override
			public void mouseExited(MouseEvent e) {
			}
			
			@Override
			public void mouseEntered(MouseEvent e) {
			}
			
			@Override
			public void mouseClicked(MouseEvent e) {
			}
		});
	}
	
	@SuppressWarnings("serial")
	static class Crtanje extends JComponent {
		
		private List<Rectangle> list = new ArrayList<>();
		
		private Point pocetak;
		private Point kraj;
		
		private void zapocniCrtanje(Point p) {
			pocetak = p;
		}
		
		private void zavrsiCrtanje(Point p) {
			kraj = p;
			int width = kraj.x - pocetak.x;
			int height = kraj.y - pocetak.y;
			
			if (width < 0) {
				width = -width;
				int tmp = pocetak.x;
				pocetak.x = kraj.x;
				kraj.x = tmp;
			}
			
			if (height < 0) {
				height = -height;
				int tmp = pocetak.y;
				pocetak.y = kraj.y;
				kraj.y = tmp;
			}
			
			Rectangle r = new Rectangle(pocetak.x, pocetak.y, width, height);
			list.add(r);
			repaint();
		}
		
		@Override
		protected void paintComponent(Graphics g) {
			g.setColor(getForeground());
			
			for (Rectangle rec : list) {
				g.drawRect(rec.x, rec.y, rec.width, rec.height);
			}
		}
	}

	public static void main(String[] args) {
		SwingUtilities.invokeLater(() -> {
			new Prozor1().setVisible(true);
		});
	}
	
}
